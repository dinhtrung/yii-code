-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 11, 2011 at 09:42 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yii_core`
--

-- --------------------------------------------------------

--
-- Table structure for table `authassignment`
--

CREATE TABLE IF NOT EXISTS `authassignment` (
  `itemname` varchar(64) NOT NULL,
  `userid` varchar(64) NOT NULL,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authassignment`
--

INSERT INTO `authassignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('Admin', '1', NULL, 'N;');

-- --------------------------------------------------------

--
-- Table structure for table `authitem`
--

CREATE TABLE IF NOT EXISTS `authitem` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `bizrule` text,
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authitem`
--

INSERT INTO `authitem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('Admin', 2, NULL, NULL, 'N;'),
('Authenticated', 2, NULL, NULL, 'N;'),
('Guest', 2, NULL, NULL, 'N;');

-- --------------------------------------------------------

--
-- Table structure for table `authitemchild`
--

CREATE TABLE IF NOT EXISTS `authitemchild` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authitemchild`
--


-- --------------------------------------------------------

--
-- Table structure for table `block`
--

CREATE TABLE IF NOT EXISTS `block` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` int(11) unsigned DEFAULT NULL,
  `region` varchar(40) DEFAULT 'content',
  `theme` varchar(40) NOT NULL,
  `option` text,
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) DEFAULT '1',
  `url` text,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `block`
--

INSERT INTO `block` (`bid`, `title`, `label`, `description`, `type`, `region`, `theme`, `option`, `sort`, `status`, `url`, `display`) VALUES
(1, 'Demo Menu Portlet', 'Demo Menu Portlet', 'Portlet động, được cấu hình thông qua hàm callback.', 1, 'sidebar', 'gtel', 'a:2:{s:4:"root";s:1:"2";s:5:"level";s:1:"1";}', 0, 1, NULL, 0),
(2, 'Another Menu', 'Another Menu', 'Another Menu on the Fly.', 1, 'sidebar', 'gtel', 'a:2:{s:4:"root";s:1:"3";s:5:"level";s:1:"2";}', 0, 1, NULL, 0),
(3, 'Node Tags', 'Tags', 'All the tags associated with the Node type.', 2, 'sidebar', 'gtel', NULL, 0, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `blocktheme`
--

CREATE TABLE IF NOT EXISTS `blocktheme` (
  `block` int(11) NOT NULL,
  `theme` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocktheme`
--


-- --------------------------------------------------------

--
-- Table structure for table `blocktype`
--

CREATE TABLE IF NOT EXISTS `blocktype` (
  `btid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `description` text,
  `component` varchar(255) DEFAULT NULL,
  `callback` varchar(40) DEFAULT NULL,
  `viewfile` varchar(255) DEFAULT NULL,
  `config` text,
  PRIMARY KEY (`btid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `blocktype`
--

INSERT INTO `blocktype` (`btid`, `title`, `description`, `component`, `callback`, `viewfile`, `config`) VALUES
(1, 'Dynamic Menu Portlet', 'A dynamic menu portlet.\r\nThe Component should be application.models.WebMenu\r\nIt must have a call back function named getMenuData() to provide the view file with needed data.\r\nThe getMenuData() will have 2 arguments: The level of the menu that will be render, and the root of the menu tree.\r\nTo configure a block of this type, the Block module must configure through WebMenu::getMenuConfig() function.', 'application.models.WebMenu', 'getMenu', '//webmenu/menuportlet', NULL),
(2, 'Node TagWidget', 'Display all the Tags belongs to node.', NULL, NULL, '/node/tagportlet', NULL),
(3, 'Tree Menu Portlet', NULL, 'application.models.WebMenu', 'getMenu', '//webmenu/menuTreePortlet', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `root` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `level` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `root` (`root`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `level` (`level`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `root`, `lft`, `rgt`, `level`, `title`, `description`) VALUES
(1, 1, 1, 4, 1, 'Node', 'This category will be used as the root of the Node categories.\r\n\r\nBy add ENestedBehavior, we can easily create Tree-like structure, as of this model.'),
(2, 1, 2, 3, 2, 'Extension Demonstration', 'The node of this type will be used as demonstration for various kind of Extension.'),
(3, 3, 1, 18, 1, 'Article', 'All Article are using this Category to categorize its content.'),
(4, 3, 2, 5, 2, 'News', 'Regular updated news'),
(5, 3, 6, 9, 2, 'Tutorials', 'Tutorial from Yii Extension repository.'),
(6, 3, 10, 15, 2, 'Yii Extension Demo', 'Demonstration of various Yii Extensions'),
(7, 3, 7, 8, 3, 'Yii Cookbook', 'Article retrieved from Yii cookbook.'),
(8, 3, 3, 4, 3, 'Ubuntu', 'Ubuntu related News'),
(9, 3, 11, 12, 3, 'Widgets', 'All demo related to Widgets'),
(10, 3, 13, 14, 3, 'Behaviors', 'Behaviors Demonstration'),
(11, 3, 16, 17, 2, 'Yii ideas', 'Ideas on Yii development');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `entity` varchar(255) NOT NULL,
  `pkey` int(11) NOT NULL,
  `uid` int(10) NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `pkey` (`pkey`),
  KEY `entity` (`entity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `root` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned NOT NULL,
  `rgt` int(10) unsigned NOT NULL,
  `level` smallint(5) unsigned NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `root` (`root`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `level` (`level`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `root`, `lft`, `rgt`, `level`, `label`, `description`, `url`, `template`, `visible`) VALUES
(1, 1, 1, 2, 1, 'Site Navigation', 'This is the main website menu.', '#navigation', NULL, 1),
(2, 2, 1, 8, 1, 'Dịch vụ cáp quang FTTH', 'Cung cấp các thông tin liên quan đến dịch vụ cáp quang FTTH.', '#ftth', NULL, 1),
(3, 3, 1, 8, 1, 'Dịch vụ thuê kênh riêng', 'Dịch vụ thuê kênh riêng.', '#subscriber', NULL, 1),
(4, 4, 1, 8, 1, 'Dịch vụ truyền hình hội nghị', 'Dịch vụ truyền hình hội nghị.', '#videoconf', NULL, 1),
(7, 2, 2, 3, 2, 'Bảng giá', 'Bảng giá cho dịch vụ FTTH', 'table-of-price', NULL, 1),
(8, 2, 4, 5, 2, 'Giới thiệu dịch vụ', 'Giới thiệu dịch vụ cung cấp đường truyền FTTH', 'duong-truyen-ftth', NULL, 1),
(9, 2, 6, 7, 2, 'Đăng ký dịch vụ', 'Thủ tục đăng ký dịch vụ.', 'dang-ky-dich-vu', NULL, 1),
(10, 3, 2, 3, 2, 'Giới thiệu', 'Giới thiệu về dịch vụ cho thuê kênh riêng.', 'gioi-thieu-thue-kenh', NULL, 1),
(11, 3, 4, 5, 2, 'Bảng giá', 'Bảng giá của dịch vụ cho thuê kênh riêng.', 'bang-gia-thue-kenh', NULL, 1),
(12, 4, 2, 3, 2, 'Giới thiệu', 'Giới thiệu dịch vụ truyền hình hội nghị.', 'video-conf', NULL, 1),
(13, 4, 4, 5, 2, 'Bảng giá', 'Bảng giá của dịch vụ Truyền hình hội nghị.', 'price-table-video', NULL, 1),
(14, 3, 6, 7, 2, 'Đăng ký dịch vụ', 'Hướng dẫn đăng ký dịch vụ cho thuê kênh riêng.', 'dangky-thue-kenh', NULL, 1),
(15, 4, 6, 7, 2, 'Đăng ký dịch vụ', 'Đăng ký dịch vụ truyền hình', 'dangky-truyen-hinh', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `node`
--

CREATE TABLE IF NOT EXISTS `node` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `tags` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `node`
--

INSERT INTO `node` (`id`, `title`, `alias`, `description`, `body`, `createtime`, `updatetime`, `uid`, `cid`, `tags`) VALUES
(1, 'Node Content', '', '\r\n	Node\r\n\r\n	C&aacute;c t&iacute;nh năng của Node:\r\n\r\n	\r\n		Li&ecirc;n kết với WebMenu để cung cấp c&aacute;c menu tr&ecirc;n hệ thống.\r\n	\r\n		Li&ecirc;n kết với Category để ph&acirc;n loại nội dung.\r\n	\r\n		Li&ecirc;n kết với Tags để ph&acirc;n loại dưới dạng', '<h2>\r\n	Node</h2>\r\n<p>\r\n	C&aacute;c t&iacute;nh năng của Node:</p>\r\n<ul>\r\n	<li>\r\n		Li&ecirc;n kết với WebMenu để cung cấp c&aacute;c menu tr&ecirc;n hệ thống.</li>\r\n	<li>\r\n		Li&ecirc;n kết với Category để ph&acirc;n loại nội dung.</li>\r\n	<li>\r\n		Li&ecirc;n kết với Tags để ph&acirc;n loại dưới dạng thẻ.</li>\r\n	<li>\r\n		Li&ecirc;n kết với Comment để th&ecirc;m lời b&igrave;nh luận.</li>\r\n	<li>\r\n		Xử dụng EavBehavior để th&ecirc;m c&aacute;c trường dữ liệu t&ugrave;y th&iacute;ch.</li>\r\n</ul>\r\n<h3>\r\n	WebMenu</h3>\r\n<p>\r\n	WebMenu c&oacute; cấu tr&uacute;c dạng c&acirc;y, được d&ugrave;ng để tổ hợp c&aacute;c menu tr&ecirc;n hệ thống.</p>\r\n<p>\r\n	WebMenu cung cấp chức năng cho block Menu, cho ph&eacute;p người d&ugrave;ng tạo 1 menu từ 1 nh&aacute;nh menu, v&agrave; số cấp tr&ecirc;n nh&aacute;nh đ&oacute;.</p>\r\n<h3>\r\n	Category</h3>\r\n<p>\r\n	Category cho ph&eacute;p ph&acirc;n loại dữ liệu dưới dạng <em>Chuy&ecirc;n mục</em>. Mỗi 1 chuy&ecirc;n mục c&oacute; thể c&oacute; nhiều kiểu Node kh&aacute;c nhau.</p>\r\n<p>\r\n	Node cho ph&eacute;p cấu h&igrave;nh c&acirc;y chuy&ecirc;n mục sẽ sử dụng để ph&acirc;n loại nội dung cho n&oacute;.</p>\r\n<h3>\r\n	Tags</h3>\r\n<p>\r\n	Tag l&agrave; c&aacute;ch ph&acirc;n loại nhiều - nhiều, cho ph&eacute;p ph&acirc;n loại nội dung dựa v&agrave;o 1 bảng tham chiếu thứ 3, giống như quan hệ MANY_MANY m&agrave; Yii cung cấp.</p>\r\n<p>\r\n	Tags được x&acirc;y dựng nhờ t&iacute;nh năng ETaggableBehavior.</p>\r\n', 1309857850, 1309879401, 1, 2, 'node, tags, category, webmenu'),
(3, 'HTML 5 Page Structure', '', '\r\n	What are the tags of structure of an HTML page in the specification 5?\r\n\r\n	It can be summarized as follows:\r\n\r\n&lt;DOCTYPE html&gt;\r\n&lt;html lang=&quot;en&quot;&gt;\r\n  &lt;head&gt;\r\n    &lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/h', '<p>\r\n	What are the tags of structure of an HTML page in the specification 5?</p>\r\n<p>\r\n	It can be summarized as follows:</p>\r\n<pre>\r\n<code>&lt;DOCTYPE html&gt;\r\n&lt;html lang=&quot;en&quot;&gt;\r\n  &lt;head&gt;\r\n    &lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=utf-8&quot; /&gt;\r\n    &lt;meta name=&quot;&quot; content=&quot;&quot;&gt;\r\n  &lt;/head&gt;\r\n&lt;/html&gt;</code></pre>\r\n<p>\r\n	What changes with HTML 5? The format is much simplified compared to the previous standard and new tags are offered.</p>\r\n<h2>\r\n	The DOCTYPE</h2>\r\n<p>\r\n	The document type has been introduced to mark the difference between the old browsers which followed the usual format in the 90s and newer browsers that are closer to the HTML specifications 3 then 4 and 5.</p>\r\n<p>\r\n	On most browser, a missing DOCTYPE is not equivalent to the HTML 5 simplified format or the previous doctypes.<br />\r\n	The lack means for Internet Explorer that the page is designed for older browsers. This may not make any difference if the latoyout is simple, consisting solely of titles and paragraphs, but if we include tables, layers and other elements, the rendering could totally change.</p>\r\n<h2>\r\n	Language</h2>\r\n<p>\r\n	The lang attribute is not for browsers, but rather to the processing tools that must understand contents according to their language.<br />\r\n	And among these tools, search engines are not included, they ignore this attribute and prefer to rely on the content to know the language.</p>\r\n<p>\r\n	It can therefore be considered optional.</p>\r\n<h2>\r\n	Head</h2>\r\n<p>\r\n	The tag contains several types of elements:</p>\r\n<ul>\r\n	<li>\r\n		Encoding with the meta tag or charset.</li>\r\n	<li>\r\n		The title of the page.</li>\r\n	<li>\r\n		Links with the link tag.</li>\r\n	<li>\r\n		And other indications by metas.</li>\r\n</ul>\r\n<h3>\r\n	Encoding</h3>\r\n<p>\r\n	The most common tag has the following form:</p>\r\n<pre>\r\n&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; charset=utf-8&quot;&gt;</pre>\r\n<p>\r\n	It defines the content type, its format that is generally text/html and its encoding, usually the utf8 charset.<br />\r\n	This tag is for the server that notifies the browser. It may be omitted if the server is configured, for example through .htaccess, to assign the format to the pages forf a given extension, like html.</p>\r\n<p>\r\n	This tag should be the first in the HEAD section, because the server will process the text above as ASCII with no specific format that it only known once the tag is analyzed.</p>\r\n<p>\r\n	This basic format is generally sufficient for all situations. There are other charsets, like iso-8859-1, but they add nothing more in the Latin world. For pages in Chinese or Japanese it is different.</p>\r\n<p>\r\n	Care must be taken however when you include dynamic content that must be encoded using the same charset.</p>\r\n<p>\r\n	HTML 5 can simplify the encoding:</p>\r\n<pre>\r\n&lt;meta charset=utf-8 &gt;</pre>\r\n<p>\r\n	This was actually implemented before HTML 5 but was not previously part of the specification. The quotes are unnecessary.</p>\r\n<p>\r\n	HTML is assumed by default, and it is only needed to specify the charset. It remains to verify that the page code is in this format, which is not necessarily automatic with all HTML editors.</p>\r\n<h3>\r\n	Links</h3>\r\n<p>\r\n	Many links can be specified in the header. Some are essential to the browser as the link to a style sheet or the RSS feed, or the favicon.</p>\r\n<p>\r\n	Others are optional as the prefetch value which loads a page in the background, and speed up the display.</p>\r\n<h4>\r\n	Sample of links</h4>\r\n<p>\r\n	Favicon</p>\r\n<pre>\r\n&lt;link rel=&quot;icon&quot; type=&quot;image/gif&quot; href=&quot;/favicon.gif&quot; /&gt;</pre>\r\n<p>\r\n	Stylesheet</p>\r\n<pre>\r\n&lt;link rel=&quot;stylesheet&quot;  type=&quot;text/css&quot; href=&quot;style.css&quot;&gt;</pre>\r\n<p>\r\n	RSS or Atom</p>\r\n<pre>\r\n&lt;link rel=&quot;alternate&quot; type=&quot;application/rss+xml&quot; href=&quot;&quot; title=&quot;&quot;&gt;</pre>\r\n<p>\r\n	Other common attributes are <em>nofollow</em> that tells search engines not to follow links on the page.</p>\r\n<h2>\r\n	Content structure</h2>\r\n<p>\r\n	In HTML 4 there is no structure specialized tags, the content is structured with &lt;div&gt; &lt;span&gt; and other containers.<br />\r\n	HTML 5 introduces multiple tags to help represent the usual structure of documents.</p>\r\n<h4>\r\n	&lt;header&gt;</h4>\r\n<p>\r\n	Contains an introduction to a part or the whole page.</p>\r\n<h4>\r\n	&lt;footer&gt;</h4>\r\n<p>\r\n	Contains information that are usually placed at the end of a section. We can put it at the end of a section or page, but also anywhere in the section.<br />\r\n	For example it contains a link on the index, which can be placed below the title.</p>\r\n<h4>\r\n	&lt;section&gt;</h4>\r\n<p>\r\n	Sections mark out parts of content. It is then up to the webmaster to associate a style sheet or using them dynamically in scripts.<br />\r\n	Very basically, we can frame a section with a border, or separate it from the above by a space.</p>\r\n<h4>\r\n	&lt;hgroup&gt;</h4>\r\n<p>\r\n	Represents the header of a section. The &lt;header&gt; tag may contain at the beginning a &lt;hgroup&gt; tag.</p>\r\n<h4>\r\n	&lt;nav&gt;</h4>\r\n<p>\r\n	This container is intended to enclose a group of links.</p>\r\n<h4>\r\n	&lt;article&gt;</h4>\r\n<p>\r\n	Denotes a typical content that can be found on different pages, or even different sites. This can be a forum post, a newspaper article and this is for tools to extract more easily the content (by separating the unnecessary data such as navigation menus).</p>\r\n<h4>\r\n	&lt;aside&gt;</h4>\r\n<p>\r\n	To delimit something separate to the actual content, and may define a sidebar.</p>\r\n<h4>\r\n	&lt;address&gt;</h4>\r\n<p>\r\n	Contains contact information, eg name of the author.</p>\r\n<h4>\r\n	&lt;mark&gt;</h4>\r\n<p>\r\n	Used to mark a portion of a text, highlight, as the old &lt;strong&gt; but more general.</p>\r\n<p>\r\n	There are many other semantic tags, which can be found described in the documents in references.</p>\r\n', 1309858954, 1309858954, 1, 1, 'html5, page elements, advanced website');

-- --------------------------------------------------------

--
-- Table structure for table `node_tag`
--

CREATE TABLE IF NOT EXISTS `node_tag` (
  `nid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  KEY `nid` (`nid`),
  KEY `tid` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_tag`
--

INSERT INTO `node_tag` (`nid`, `tid`) VALUES
(3, 7),
(3, 8),
(3, 9),
(1, 4),
(1, 2),
(1, 1),
(1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `user_id` int(11) NOT NULL,
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`user_id`, `lastname`, `firstname`, `birthday`) VALUES
(1, 'Admin', 'Administrator', '0000-00-00'),
(2, 'Demo', 'Demo', '0000-00-00'),
(3, 'Dinh Trung', 'Nguyen', '1985-01-14'),
(4, 'One', 'Teacher', '0000-00-00'),
(5, 'Hai', 'Teacher', '0000-00-00'),
(6, 'One', 'Manager', '0000-00-00'),
(7, 'Hai', 'Manager', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `profiles_fields`
--

CREATE TABLE IF NOT EXISTS `profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `profiles_fields`
--

INSERT INTO `profiles_fields` (`id`, `varname`, `title`, `field_type`, `field_size`, `field_size_min`, `required`, `match`, `range`, `error_message`, `other_validator`, `default`, `widget`, `widgetparams`, `position`, `visible`) VALUES
(1, 'lastname', 'Last Name', 'VARCHAR', 50, 3, 1, '', '', 'Incorrect Last Name (length between 3 and 50 characters).', '', '', '', '', 1, 3),
(2, 'firstname', 'First Name', 'VARCHAR', 50, 3, 1, '', '', 'Incorrect First Name (length between 3 and 50 characters).', '', '', '', '', 0, 3),
(3, 'birthday', 'Birthday', 'DATE', 0, 0, 2, '', '', '', '', '0000-00-00', 'UWjuidate', '{"ui-theme":"redmond"}', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `rights`
--

CREATE TABLE IF NOT EXISTS `rights` (
  `itemname` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  PRIMARY KEY (`itemname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rights`
--


-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(64) NOT NULL DEFAULT 'system',
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_key` (`category`,`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `category`, `key`, `value`) VALUES
(1, 'theme', 'perPage', 's:2:"20";'),
(2, 'theme', 'serverEmail', 's:0:"";'),
(3, 'theme', 'contactEmail', 's:0:"";'),
(4, 'theme', 'theme', 's:4:"gtel";'),
(5, 'theme', 'layout', 'N;'),
(6, 'theme', 'siteName', 's:13:"Internet GTel";'),
(7, 'theme', 'siteSlogan', 'N;'),
(8, 'theme', 'siteLogo', 's:0:"";'),
(9, 'article', 'image', 's:0:"";'),
(10, 'article', 'cid', 's:1:"3";'),
(11, 'article', 'alias', 's:20:"webroot.files.upload";'),
(12, 'document', 'alias', 's:21:"webroot.files.uploads";'),
(13, 'document', 'image', 's:0:"";'),
(14, 'document', 'cid', 's:1:"3";');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `frequency` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `frequency`) VALUES
(1, 'category', 2),
(2, 'tags', 2),
(3, 'webmenu', 2),
(4, 'node', 2),
(5, 'content', 1),
(6, 'duplicate', 1),
(7, 'html5', 2),
(8, 'page elements', 2),
(9, 'advanced website', 2),
(10, 'processor', 2),
(11, 'file', 3),
(12, 'image', 2),
(13, 'behavior', 2),
(14, 'model', 3),
(15, 'active record', 2),
(16, 'activerecord', 2),
(17, 'array', 2),
(18, 'data', 2),
(19, 'find', 2),
(20, 'validate', 2),
(21, 'save', 2),
(22, 'configure', 2),
(23, 'config', 2),
(24, 'voip', 2),
(25, 'freeswitch', 2),
(26, 'uniform', 2),
(27, 'form', 2),
(28, 'theme', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(10) NOT NULL DEFAULT '0',
  `lastvisit` int(10) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activkey`, `createtime`, `lastvisit`, `superuser`, `status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'webmaster@example.com', '9a24eff8c15a6a141ece27eb6947da0f', 1261146094, 1310355386, 1, 1),
(2, 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'demo@example.com', '099f825543f7850cc038b90aaff39fac', 1261146096, 0, 0, 1),
(3, 'ndtrung', 'e10adc3949ba59abbe56e057f20f883e', 'ndtrung@istt.com.vn', 'ee1ee8aaa2b5eb52e0caac370172814b', 1307011935, 0, 0, 0),
(4, 'teacher1', 'e10adc3949ba59abbe56e057f20f883e', 'teacher1@yiiedupro.com', 'bf09249421f3c9d8e0feab86bfce0757', 1308593633, 1308593633, 0, 1),
(5, 'teacher2', 'e10adc3949ba59abbe56e057f20f883e', 'teacher2@yiiedupro.com', '5eb6c4db0584b5ce468a0249044e567d', 1308593660, 1308593660, 0, 1),
(6, 'manager1', 'e10adc3949ba59abbe56e057f20f883e', 'manager1@edupro.com', 'f547e7a74e9dad726cfc318262434f29', 1308593687, 1308593687, 0, 1),
(7, 'manager2', 'e10adc3949ba59abbe56e057f20f883e', 'manager2@yiiedupro.com', 'bd10823945c501005226dc2db67d162e', 1308593711, 1308593711, 0, 1);
