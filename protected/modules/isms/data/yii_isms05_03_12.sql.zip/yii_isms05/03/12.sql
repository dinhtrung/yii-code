-- phpMyAdmin SQL Dump
-- version 3.3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 03, 2012 at 03:19 PM
-- Server version: 5.1.45
-- PHP Version: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yii_isms`
--

-- --------------------------------------------------------

--
-- Table structure for table `authassignment`
--

CREATE TABLE IF NOT EXISTS `authassignment` (
  `itemname` varchar(255) DEFAULT NULL COMMENT 'authitem.name',
  `userid` int(11) DEFAULT NULL COMMENT 'user.id',
  `bizrule` text COMMENT 'Business rules',
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authassignment`
--

INSERT INTO `authassignment` (`itemname`, `userid`, `bizrule`, `data`) VALUES
('Admin', 1, NULL, 'N;'),
('iSMS Partner', 2, NULL, 'N;'),
('iSMS Admin', 3, NULL, 'N;');

-- --------------------------------------------------------

--
-- Table structure for table `authitem`
--

CREATE TABLE IF NOT EXISTS `authitem` (
  `name` varchar(255) NOT NULL COMMENT 'Name of the authitem',
  `type` int(11) NOT NULL COMMENT '0|operation, 1|task, 2|role',
  `description` text COMMENT 'Not used. Use dbmessages instead.',
  `bizrule` text COMMENT 'Business rule',
  `data` text,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authitem`
--

INSERT INTO `authitem` (`name`, `type`, `description`, `bizrule`, `data`) VALUES
('Admin', 2, NULL, NULL, 'N;'),
('Cms.Category.*', 1, NULL, NULL, 'N;'),
('Cms.Category.Admin', 0, NULL, NULL, 'N;'),
('Cms.Node.*', 1, NULL, NULL, 'N;'),
('Cms.Tags.*', 1, NULL, NULL, 'N;'),
('Cms.Tags.Admin', 0, NULL, NULL, 'N;'),
('Cms.Tags.Delete', 0, NULL, NULL, 'N;'),
('Cms.Tags.Update', 0, NULL, NULL, 'N;'),
('Cms.Webmenu.*', 1, NULL, NULL, 'N;'),
('Cms.Webmenu.Admin', 0, NULL, NULL, 'N;'),
('Core.Block.*', 1, NULL, NULL, 'N;'),
('Core.Block.Admin', 0, NULL, NULL, 'N;'),
('Core.Block.Configure', 0, NULL, NULL, 'N;'),
('Core.Block.Create', 0, NULL, NULL, 'N;'),
('Core.Block.Delete', 0, NULL, NULL, 'N;'),
('Core.Block.Duplicate', 0, NULL, NULL, 'N;'),
('Core.Block.Theme', 0, NULL, NULL, 'N;'),
('Core.Block.Update', 0, NULL, NULL, 'N;'),
('Core.Block.View', 0, NULL, NULL, 'N;'),
('Core.Blocktype.*', 1, NULL, NULL, 'N;'),
('Core.Blocktype.Admin', 0, NULL, NULL, 'N;'),
('Core.Blocktype.Clone', 0, NULL, NULL, 'N;'),
('Core.Blocktype.Create', 0, NULL, NULL, 'N;'),
('Core.Blocktype.Delete', 0, NULL, NULL, 'N;'),
('Core.Blocktype.Duplicate', 0, NULL, NULL, 'N;'),
('Core.Blocktype.Update', 0, NULL, NULL, 'N;'),
('Core.Blocktype.View', 0, NULL, NULL, 'N;'),
('Core.Log.*', 1, NULL, NULL, 'N;'),
('Core.Log.Admin', 0, NULL, NULL, 'N;'),
('Core.Log.Delete', 0, NULL, NULL, 'N;'),
('Core.Webtheme.*', 1, NULL, NULL, 'N;'),
('Core.Webtheme.Index', 0, NULL, NULL, 'N;'),
('Core.Webtheme.View', 0, NULL, NULL, 'N;'),
('iSMS Admin', 2, 'iSMS Admin', NULL, 'N;'),
('iSMS Partner', 2, 'iSMS Partner', NULL, 'N;'),
('Isms.Blacklist.*', 1, NULL, NULL, 'N;'),
('Isms.Blacklist.Admin', 0, NULL, NULL, 'N;'),
('Isms.Blacklist.Create', 0, NULL, NULL, 'N;'),
('Isms.Blacklist.Delete', 0, NULL, NULL, 'N;'),
('Isms.Blacklist.Update', 0, NULL, NULL, 'N;'),
('Isms.Campaign.*', 1, NULL, NULL, 'N;'),
('Isms.Campaign.Create', 0, NULL, NULL, 'N;'),
('Isms.Campaign.Delete', 0, NULL, NULL, 'N;'),
('Isms.Campaign.Index', 0, NULL, NULL, 'N;'),
('Isms.Campaign.Update', 0, NULL, NULL, 'N;'),
('Isms.Campaign.Upload', 0, NULL, NULL, 'N;'),
('Isms.Campaign.View', 0, NULL, NULL, 'N;'),
('Isms.Cpfile.*', 1, NULL, NULL, 'N;'),
('Isms.Cpfile.Admin', 0, NULL, NULL, 'N;'),
('Isms.Cpfile.Create', 0, NULL, NULL, 'N;'),
('Isms.Cpfile.Delete', 0, NULL, NULL, 'N;'),
('Isms.Cpfile.Update', 0, NULL, NULL, 'N;'),
('Isms.Cpfilter.*', 1, NULL, NULL, 'N;'),
('Isms.Cpfilter.Admin', 0, NULL, NULL, 'N;'),
('Isms.Cpfilter.Create', 0, NULL, NULL, 'N;'),
('Isms.Cpfilter.Delete', 0, NULL, NULL, 'N;'),
('Isms.Cpfilter.Update', 0, NULL, NULL, 'N;'),
('Isms.Cpworktime.*', 1, NULL, NULL, 'N;'),
('Isms.Cpworktime.Admin', 0, NULL, NULL, 'N;'),
('Isms.Cpworktime.Create', 0, NULL, NULL, 'N;'),
('Isms.Cpworktime.Delete', 0, NULL, NULL, 'N;'),
('Isms.Cpworktime.Update', 0, NULL, NULL, 'N;'),
('Isms.Dailyreport.*', 1, NULL, NULL, 'N;'),
('Isms.Dailyreport.Admin', 0, NULL, NULL, 'N;'),
('Isms.Dailyreport.Create', 0, NULL, NULL, 'N;'),
('Isms.Dailyreport.Delete', 0, NULL, NULL, 'N;'),
('Isms.Dailyreport.Update', 0, NULL, NULL, 'N;'),
('Isms.Datafile.*', 1, NULL, NULL, 'N;'),
('Isms.Datafile.Admin', 0, NULL, NULL, 'N;'),
('Isms.Datafile.Create', 0, NULL, NULL, 'N;'),
('Isms.Datafile.Delete', 0, NULL, NULL, 'N;'),
('Isms.Datafile.Update', 0, NULL, NULL, 'N;'),
('Isms.Datafile.View', 0, NULL, NULL, 'N;'),
('Isms.Emailsetting.*', 1, NULL, NULL, 'N;'),
('Isms.Emailsetting.Admin', 0, NULL, NULL, 'N;'),
('Isms.Emailsetting.Create', 0, NULL, NULL, 'N;'),
('Isms.Emailsetting.Delete', 0, NULL, NULL, 'N;'),
('Isms.Emailsetting.Update', 0, NULL, NULL, 'N;'),
('Isms.Emailsetting.View', 0, NULL, NULL, 'N;'),
('Isms.Filter.*', 1, NULL, NULL, 'N;'),
('Isms.Filter.Blacklist', 0, NULL, NULL, 'N;'),
('Isms.Filter.Create', 0, NULL, NULL, 'N;'),
('Isms.Filter.Delete', 0, NULL, NULL, 'N;'),
('Isms.Filter.Index', 0, NULL, NULL, 'N;'),
('Isms.Filter.Update', 0, NULL, NULL, 'N;'),
('Isms.Filter.View', 0, NULL, NULL, 'N;'),
('Isms.Filter.Whitelist', 0, NULL, NULL, 'N;'),
('Isms.Ftpfilename.*', 1, NULL, NULL, 'N;'),
('Isms.Ftpfilename.Admin', 0, NULL, NULL, 'N;'),
('Isms.Ftpfilename.Create', 0, NULL, NULL, 'N;'),
('Isms.Ftpfilename.Delete', 0, NULL, NULL, 'N;'),
('Isms.Ftpfilename.Update', 0, NULL, NULL, 'N;'),
('Isms.Ftpsetting.*', 1, NULL, NULL, 'N;'),
('Isms.Ftpsetting.Admin', 0, NULL, NULL, 'N;'),
('Isms.Ftpsetting.Create', 0, NULL, NULL, 'N;'),
('Isms.Ftpsetting.Delete', 0, NULL, NULL, 'N;'),
('Isms.Ftpsetting.Update', 0, NULL, NULL, 'N;'),
('Isms.Organization.*', 1, NULL, NULL, 'N;'),
('Isms.Organization.Admin', 0, NULL, NULL, 'N;'),
('Isms.Organization.Create', 0, NULL, NULL, 'N;'),
('Isms.Organization.Delete', 0, NULL, NULL, 'N;'),
('Isms.Organization.Update', 0, NULL, NULL, 'N;'),
('Isms.Organization.View', 0, NULL, NULL, 'N;'),
('Isms.Sendsms.*', 1, NULL, NULL, 'N;'),
('Isms.Sendsms.Admin', 0, NULL, NULL, 'N;'),
('Isms.Sendsms.Create', 0, NULL, NULL, 'N;'),
('Isms.Sendsms.Delete', 0, NULL, NULL, 'N;'),
('Isms.Sendsms.Update', 0, NULL, NULL, 'N;'),
('Isms.SentSms.*', 1, NULL, NULL, 'N;'),
('Isms.SentSms.Admin', 0, NULL, NULL, 'N;'),
('Isms.SentSms.Create', 0, NULL, NULL, 'N;'),
('Isms.SentSms.Delete', 0, NULL, NULL, 'N;'),
('Isms.SentSms.Update', 0, NULL, NULL, 'N;'),
('Isms.Smsorder.*', 1, NULL, NULL, 'N;'),
('Isms.Smsorder.Admin', 0, NULL, NULL, 'N;'),
('Isms.Smsorder.Create', 0, NULL, NULL, 'N;'),
('Isms.Smsorder.Delete', 0, NULL, NULL, 'N;'),
('Isms.Smsorder.Update', 0, NULL, NULL, 'N;'),
('Isms.Smsorder.View', 0, NULL, NULL, 'N;'),
('Isms.Syntax.*', 1, NULL, NULL, 'N;'),
('Isms.Syntax.Admin', 0, NULL, NULL, 'N;'),
('Isms.Syntax.Create', 0, NULL, NULL, 'N;'),
('Isms.Syntax.Delete', 0, NULL, NULL, 'N;'),
('Isms.Syntax.Update', 0, NULL, NULL, 'N;'),
('Isms.Template.*', 1, NULL, NULL, 'N;'),
('Isms.Template.Admin', 0, NULL, NULL, 'N;'),
('Isms.Template.Create', 0, NULL, NULL, 'N;'),
('Isms.Template.Delete', 0, NULL, NULL, 'N;'),
('Isms.Template.Update', 0, NULL, NULL, 'N;'),
('Isms.Whitelist.*', 1, NULL, NULL, 'N;'),
('Isms.Whitelist.Admin', 0, NULL, NULL, 'N;'),
('Isms.Whitelist.Create', 0, NULL, NULL, 'N;'),
('Isms.Whitelist.Delete', 0, NULL, NULL, 'N;'),
('Isms.Whitelist.Update', 0, NULL, NULL, 'N;'),
('Isms.Worktime.*', 1, NULL, NULL, 'N;'),
('Isms.Worktime.Admin', 0, NULL, NULL, 'N;'),
('Isms.Worktime.Create', 0, NULL, NULL, 'N;'),
('Isms.Worktime.Delete', 0, NULL, NULL, 'N;'),
('Isms.Worktime.Update', 0, NULL, NULL, 'N;'),
('User.Admin.*', 1, NULL, NULL, 'N;'),
('User.Admin.Admin', 0, NULL, NULL, 'N;'),
('User.Admin.Create', 0, NULL, NULL, 'N;'),
('User.Admin.Delete', 0, NULL, NULL, 'N;'),
('User.Admin.Update', 0, NULL, NULL, 'N;'),
('User.Admin.View', 0, NULL, NULL, 'N;');

-- --------------------------------------------------------

--
-- Table structure for table `authitemchild`
--

CREATE TABLE IF NOT EXISTS `authitemchild` (
  `parent` varchar(255) DEFAULT NULL COMMENT 'authitem.name of parent',
  `child` varchar(255) DEFAULT NULL COMMENT 'authitem.name of child'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authitemchild`
--

INSERT INTO `authitemchild` (`parent`, `child`) VALUES
('iSMS Admin', 'User.Admin.Admin'),
('User.Admin.Admin', 'User.Admin.Create'),
('User.Admin.Create', 'User.Admin.Update'),
('User.Admin.Update', 'User.Admin.Delete'),
('User.Admin.Delete', 'User.Admin.View'),
('iSMS Admin', 'Isms.Campaign.Index'),
('Isms.Campaign.Index', 'Isms.Campaign.Create'),
('iSMS Admin', 'iSMS Partner'),
('iSMS Partner', 'Isms.Campaign.Create'),
('Isms.Campaign.Create', 'Isms.Campaign.Update'),
('Isms.Campaign.Update', 'Isms.Campaign.Delete'),
('Isms.Campaign.Delete', 'Isms.Campaign.View'),
('Isms.Campaign.View', 'Isms.Cpfile.Admin'),
('Isms.Campaign.View', 'Isms.Cpfilter.Admin'),
('Isms.Campaign.View', 'Isms.Cpworktime.Admin'),
('Isms.Campaign.View', 'Isms.Dailyreport.Admin'),
('Isms.Campaign.View', 'Isms.Emailsetting.Admin'),
('Isms.Campaign.View', 'Isms.Datafile.Admin'),
('Isms.Campaign.View', 'Isms.Ftpfilename.Admin'),
('Isms.Campaign.View', 'Isms.Sendsms.Admin'),
('Isms.Campaign.View', 'Isms.Organization.View'),
('Isms.Campaign.View', 'Isms.SentSms.Admin'),
('Isms.Campaign.View', 'Isms.Smsorder.View'),
('Isms.Campaign.View', 'Isms.Worktime.Admin'),
('iSMS Admin', 'Isms.Filter.*'),
('iSMS Admin', 'Isms.Smsorder.*'),
('iSMS Admin', 'Isms.Ftpsetting.*'),
('iSMS Admin', 'Isms.Ftpfilename.*'),
('iSMS Admin', 'Isms.Datafile.*'),
('iSMS Admin', 'Isms.Whitelist.*'),
('iSMS Admin', 'Isms.Blacklist.*'),
('Isms.Filter.*', 'Isms.Cpfilter.*'),
('Isms.Campaign.*', 'Isms.Datafile.*'),
('Isms.Campaign.*', 'Isms.Ftpsetting.*'),
('Isms.Campaign.*', 'Isms.Emailsetting.*'),
('Isms.Campaign.*', 'Isms.Sendsms.*'),
('Isms.Campaign.*', 'Isms.SentSms.*'),
('Isms.Campaign.*', 'Isms.Template.*'),
('Isms.Campaign.*', 'Isms.Ftpfilename.*'),
('Isms.Campaign.*', 'Isms.Worktime.*'),
('Isms.Worktime.*', 'Isms.Cpworktime.*'),
('Isms.Syntax.*', 'Isms.Blacklist.*'),
('Isms.Syntax.*', 'Isms.Whitelist.*'),
('Isms.Syntax.*', 'Isms.Cpfilter.*'),
('Isms.Smsorder.*', 'Isms.Campaign.Create'),
('Isms.Datafile.*', 'Isms.Cpfile.*'),
('Isms.Ftpsetting.*', 'Isms.Ftpfilename.*'),
('Isms.Filter.*', 'Isms.Syntax.*');

-- --------------------------------------------------------

--
-- Table structure for table `blacklist`
--

CREATE TABLE IF NOT EXISTS `blacklist` (
  `fid` int(11) NOT NULL COMMENT 'filter.id',
  `isdn` varchar(20) NOT NULL DEFAULT '' COMMENT 'Phone number of the customer',
  PRIMARY KEY (`fid`,`isdn`),
  KEY `phonenumber` (`isdn`),
  KEY `fid` (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blacklist`
--


-- --------------------------------------------------------

--
-- Table structure for table `block`
--

CREATE TABLE IF NOT EXISTS `block` (
  `bid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Block ID',
  `title` varchar(100) DEFAULT 'NULL' COMMENT 'Block Administration Title',
  `label` varchar(255) NOT NULL COMMENT 'Block label, display for end user',
  `description` text NOT NULL COMMENT 'Description for Administrators',
  `type` int(11) DEFAULT NULL COMMENT 'Blocktype.id',
  `option` text COMMENT 'Serialized parameters for this block',
  `status` int(1) DEFAULT NULL COMMENT '0:disabled, 1:enabled',
  `url` text COMMENT 'display status filtered by URL, like in Drupal CMS',
  `display` int(1) NOT NULL COMMENT '0:display except some page, 1: only some page',
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `block`
--


-- --------------------------------------------------------

--
-- Table structure for table `blocktheme`
--

CREATE TABLE IF NOT EXISTS `blocktheme` (
  `block` int(11) DEFAULT NULL COMMENT 'block.bid',
  `theme` varchar(255) DEFAULT NULL COMMENT 'name of the theme',
  `region` varchar(40) DEFAULT NULL COMMENT 'region this theme provide',
  `weight` int(3) NOT NULL COMMENT 'order this block is rendered.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocktheme`
--


-- --------------------------------------------------------

--
-- Table structure for table `blocktype`
--

CREATE TABLE IF NOT EXISTS `blocktype` (
  `btid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'block type ID',
  `title` varchar(100) DEFAULT 'NULL' COMMENT 'Name of this block type',
  `description` text COMMENT 'description for this block type',
  `component` varchar(255) DEFAULT 'NULL' COMMENT 'Yii class path for calling this component',
  `callback` varchar(255) DEFAULT 'NULL' COMMENT 'callback function the component provide',
  `viewfile` varchar(255) DEFAULT 'NULL' COMMENT 'view file need to render',
  PRIMARY KEY (`btid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `blocktype`
--


-- --------------------------------------------------------

--
-- Table structure for table `campaign`
--

CREATE TABLE IF NOT EXISTS `campaign` (
  `id` int(9) NOT NULL AUTO_INCREMENT COMMENT 'Campaign ID',
  `title` varchar(40) DEFAULT '' COMMENT 'Name of the campaign',
  `description` text COMMENT 'Description along this campaign',
  `createtime` int(11) DEFAULT NULL COMMENT 'Timestamp upon create',
  `updatetime` int(11) DEFAULT NULL COMMENT 'Timestamp upon update',
  `codename` varchar(20) DEFAULT '' COMMENT 'Ma so chuong trinh nhan tin',
  `request_date` date DEFAULT NULL COMMENT 'Ngay cong van yeu cau',
  `request_owner` varchar(40) DEFAULT '' COMMENT 'Don vi yeu cau chuong trinh',
  `datasender` varchar(80) DEFAULT NULL COMMENT 'Don vi gui du lieu chuong trinh',
  `tosubscriber` text COMMENT 'Doi tuong khach hang',
  `start` datetime DEFAULT NULL COMMENT 'Thoi gian bat dau',
  `end` datetime DEFAULT NULL COMMENT 'Thoi gian het hieu luc.',
  `status` int(1) DEFAULT '0' COMMENT 'Trang thai cua chuong trinh. 0:Khong bat, 1: Duoc bat',
  `approved` tinyint(1) NOT NULL COMMENT 'Quan tri vien da xet duyet chuong trinh? 0: Chua duyet, 1: Da duyet',
  `finished` tinyint(1) NOT NULL COMMENT 'Chuong trinh da hoan thanh? 0: Kannel chua chay chuong trinh, 1: Kannel chay xong chuong trinh roi.',
  `active` tinyint(1) NOT NULL COMMENT 'Dang den gio chay chua? 0: Chua den gio chay, 1: Dang trong thoi gian chay. Xem them worktime và cpworkday',
  `sender` varchar(20) DEFAULT NULL COMMENT 'Dau so gui tin nhan',
  `ready` int(1) DEFAULT NULL COMMENT 'Trang thai nhap du lieu. 0: Chua nhap du lieu, 1: Dang nhap du lieu, 2: Da nhap xong du lieu',
  `org` int(11) DEFAULT '0' COMMENT 'Trung tam nao chay chuong trinh nay? Moi trung tam co 2 server gui tin nhan. Xem organization.id. Co bearerbox=org thi duoc chay.',
  `type` tinyint(1) DEFAULT '0' COMMENT 'Loai chuong trinh. Khong dung nua.',
  `col` int(11) DEFAULT '1' COMMENT 'So cot du lieu trong file .CSV gui len he thong.',
  `isdncol` int(11) NOT NULL DEFAULT '1' COMMENT 'Cot du lieu so dien thoai khach hang la cot thu may?',
  `template` text COMMENT 'Noi dung tin nhan gui cho khach hang.',
  `throughput` int(11) DEFAULT NULL COMMENT 'So tin nhan chon trong 1 chu ky gui tin.',
  `priority` tinyint(6) DEFAULT '0' COMMENT 'Do uu tien khi chon chuong trinh de chay. Cung do uu tien va thoi gian chay, se duoc chay dong thoi cung nhau',
  `velocity` int(11) DEFAULT '1' COMMENT 'Toc do gui tin trong moi giay',
  `cpworkday` varchar(10) NOT NULL COMMENT 'Cac ngay trong tuan duoc phep gui tin. 1:Sunday - 7:Saturday, vd: 12367',
  `emailbox` int(11) DEFAULT NULL COMMENT 'Hop thu can kiem tra noi dung tin nhan moi',
  `esubject` varchar(255) DEFAULT NULL COMMENT 'Tieu de thu gui toi can kiem tra',
  `eattachment` varchar(255) DEFAULT NULL COMMENT 'Ten tep tin chua noi dung moi',
  `ftpserver` int(11) DEFAULT NULL COMMENT 'Ket noi FTP de lay du lieu ve',
  `smsimport` bigint(20) DEFAULT NULL COMMENT 'Number of SMS imported',
  `blockimport` bigint(20) DEFAULT NULL COMMENT 'Number of SMS block imported.',
  `send` bigint(20) NOT NULL COMMENT 'So luong SMS dang cho gui',
  `blocksend` bigint(20) NOT NULL COMMENT 'So luong SMS block 160 ky tu dang cho gui',
  `sent` bigint(20) NOT NULL COMMENT 'So luong SMS da gui',
  `blocksent` bigint(20) NOT NULL COMMENT 'So luong SMS 160kt da gui',
  `userid` int(11) NOT NULL COMMENT 'user.id tuong ung voi ma don hang cua chuong trinh',
  `orderid` int(11) NOT NULL COMMENT 'Ma don hang tinh cho chuong trinh nay. smsorder.id',
  PRIMARY KEY (`id`),
  KEY `emailbox` (`emailbox`),
  KEY `fftpsetting` (`ftpserver`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `campaign`
--

INSERT INTO `campaign` (`id`, `title`, `description`, `createtime`, `updatetime`, `codename`, `request_date`, `request_owner`, `datasender`, `tosubscriber`, `start`, `end`, `status`, `approved`, `finished`, `active`, `sender`, `ready`, `org`, `type`, `col`, `isdncol`, `template`, `throughput`, `priority`, `velocity`, `cpworkday`, `emailbox`, `esubject`, `eattachment`, `ftpserver`, `smsimport`, `blockimport`, `send`, `blocksend`, `sent`, `blocksent`, `userid`, `orderid`) VALUES
(1, 'Thu nghiem chuc nang', 'Day la 1 chuong trinh de thu nghiem chuc nang cua he thong iSMS v3', 1335927840, 1335929000, 'NOLIMIT', '0000-00-00', '', '', '', '2012-05-02 00:00:00', '2012-05-31 00:00:00', 1, 1, 1, 0, 'ISTT', 2, 0, 0, 1, 1, 'Day la chuong trinh nhan tin danh cho so thue bao: {isdn}', 180, 120, 120, '1234567', NULL, '', '', NULL, NULL, NULL, 0, 0, 0, 0, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Ma chuyen muc',
  `root` int(10) DEFAULT NULL COMMENT 'Chuyen muc cap tren',
  `lft` int(10) NOT NULL COMMENT 'Chuyen muc truoc',
  `rgt` int(10) NOT NULL COMMENT 'Chuyen muc sau',
  `level` int(5) NOT NULL COMMENT 'Do sau cua chuyen muc',
  `title` varchar(255) NOT NULL COMMENT 'Ten chuyen muc',
  `description` text NOT NULL COMMENT 'Mo ta cho chuyen muc',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `category`
--


-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(255) NOT NULL,
  `pkey` int(11) NOT NULL,
  `uid` int(10) NOT NULL COMMENT 'User.id',
  `createtime` int(10) NOT NULL,
  `visible` int(1) NOT NULL,
  `comment` text COMMENT 'Noi dung binh luan',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `cpfile`
--

CREATE TABLE IF NOT EXISTS `cpfile` (
  `cid` int(11) NOT NULL COMMENT 'Campaign.id',
  `fid` int(11) NOT NULL COMMENT 'Datafile.id',
  `status` int(1) NOT NULL COMMENT '0:chua xu ly,1:dang xu ly, 2:da xu ly',
  PRIMARY KEY (`cid`,`fid`),
  KEY `cid` (`cid`),
  KEY `fid` (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cpfile`
--

INSERT INTO `cpfile` (`cid`, `fid`, `status`) VALUES
(1, 2, 1),
(1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cpfilter`
--

CREATE TABLE IF NOT EXISTS `cpfilter` (
  `cid` int(11) NOT NULL COMMENT 'Campaign.id',
  `fid` int(11) NOT NULL COMMENT 'Filter.id',
  `type` int(1) NOT NULL COMMENT '0:blacklist, 1:whitelist',
  PRIMARY KEY (`cid`,`fid`),
  KEY `fid` (`fid`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cpfilter`
--


-- --------------------------------------------------------

--
-- Table structure for table `cpworktime`
--

CREATE TABLE IF NOT EXISTS `cpworktime` (
  `cid` int(11) NOT NULL COMMENT 'Campaign.id',
  `tid` int(11) NOT NULL COMMENT 'Worktime.id',
  PRIMARY KEY (`cid`,`tid`),
  KEY `cid` (`cid`),
  KEY `tid` (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cpworktime`
--


-- --------------------------------------------------------

--
-- Table structure for table `dailyreport`
--

CREATE TABLE IF NOT EXISTS `dailyreport` (
  `id_dailyreport` int(11) NOT NULL AUTO_INCREMENT,
  `created_date` date NOT NULL,
  `sms_sent` int(11) NOT NULL,
  `block_sent` int(11) NOT NULL,
  `sms_delivered` int(11) NOT NULL,
  `block_delivered` int(11) NOT NULL,
  `campaign_id` int(11) NOT NULL,
  PRIMARY KEY (`id_dailyreport`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `dailyreport`
--

INSERT INTO `dailyreport` (`id_dailyreport`, `created_date`, `sms_sent`, `block_sent`, `sms_delivered`, `block_delivered`, `campaign_id`) VALUES
(1, '2012-04-10', 500, 200, 500, 400, 1);

-- --------------------------------------------------------

--
-- Table structure for table `datafile`
--

CREATE TABLE IF NOT EXISTS `datafile` (
  `fid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'File ID.',
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The users.uid of the user who is associated with the file.',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT 'Name of the file with no path components. This may differ from the basename of the URI if the file is renamed to avoid overwriting an existing file.',
  `uri` varchar(255) NOT NULL DEFAULT '' COMMENT 'The URI to access the file (either local or remote).',
  `filemime` varchar(255) NOT NULL DEFAULT '' COMMENT 'The file’s MIME type.',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The size of the file in bytes.',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'A field indicating the status of the file. Two status are defined in core: temporary (0) and permanent (1). Temporary files older than DRUPAL_MAXIMUM_TEMP_FILE_AGE will be removed during a cron run.',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'UNIX timestamp for when the file was added.',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `uri` (`uri`),
  KEY `uid` (`createtime`),
  KEY `status` (`status`),
  KEY `timestamp` (`updatetime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Stores information for uploaded files.' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `datafile`
--


-- --------------------------------------------------------

--
-- Table structure for table `emailsetting`
--

CREATE TABLE IF NOT EXISTS `emailsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(40) NOT NULL COMMENT 'IP hoac hostname cua mail server',
  `email` varchar(255) NOT NULL COMMENT 'Dia chi Email',
  `password` varchar(255) NOT NULL COMMENT 'Mat khau dang nhap',
  `option` varchar(255) NOT NULL COMMENT 'Cac tham so cua imap_open',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `emailsetting`
--

INSERT INTO `emailsetting` (`id`, `hostname`, `email`, `password`, `option`) VALUES
(1, 'mail.istt.com.vn', 'ndtrung@istt.com.vn', '123456', 'debug/imap');

-- --------------------------------------------------------

--
-- Table structure for table `filter`
--

CREATE TABLE IF NOT EXISTS `filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) DEFAULT NULL COMMENT 'Ten cua bo loc tin nhan',
  `reply_refuse` varchar(256) DEFAULT 'Ban da tu choi thanh cong dich vu' COMMENT 'Noi dung tin nhan tra loi khi khach hang dang ky tu choi tin nhan qua bo loc nay',
  `reply_accept` varchar(256) DEFAULT 'Ban da chap nhan thanh cong dich vu' COMMENT 'Noi dung tin nhan tra loi khi khach hang dang ky nhan tin nhan qua bo loc nay',
  `reply_false_syntax` varchar(256) DEFAULT 'Ban da nhap sai cu phap',
  `description` varchar(256) DEFAULT NULL COMMENT 'Mo ta cho bo loc tin nhan nay',
  `ftpblack` int(11) DEFAULT NULL COMMENT 'FTP Server ID for this filter - blacklist sync',
  `ftpblackfile` varchar(255) DEFAULT NULL COMMENT 'Filename prefix for blacklist sync',
  `ftpwhite` int(11) DEFAULT NULL COMMENT 'FTP Server ID for this filter - whitelist sync',
  `ftpwhitefile` varchar(255) DEFAULT NULL COMMENT 'Filename prefix for Whitelist sycn',
  PRIMARY KEY (`id`),
  KEY `ftpblack` (`ftpblack`),
  KEY `ftpwhite` (`ftpwhite`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `filter`
--

INSERT INTO `filter` (`id`, `title`, `reply_refuse`, `reply_accept`, `reply_false_syntax`, `description`, `ftpblack`, `ftpblackfile`, `ftpwhite`, `ftpwhitefile`) VALUES
(1, '9241', 'Ban da tu choi thanh cong dich vu', 'Ban da chap nhan thanh cong dich vu', 'Ban da nhap sai cu phap', 'Day la dich vu loc tin nhan mac dinh, dong bo voi du lieu hien co cua server 9241.', 1, 'tuchoi_', 1, 'dangky_'),
(2, 'ISTT Demo', 'Ban da tu choi thanh cong dich vu', 'Ban da chap nhan thanh cong dich vu', 'Ban da nhap sai cu phap', 'Day la dich vu thu nghiem cho iSMS v3 do ISTT xay dung.', 1, 'istt_black_', 1, 'istt_white_');

-- --------------------------------------------------------

--
-- Table structure for table `ftpfilename`
--

CREATE TABLE IF NOT EXISTS `ftpfilename` (
  `cid` int(11) NOT NULL COMMENT 'Campaign.id',
  `filename` varchar(255) NOT NULL COMMENT 'Ten tep tin can tim kiem',
  `status` int(1) NOT NULL COMMENT '0:chua xu ly, 1:da xu ly',
  PRIMARY KEY (`cid`,`filename`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ftpfilename`
--


-- --------------------------------------------------------

--
-- Table structure for table `ftpsetting`
--

CREATE TABLE IF NOT EXISTS `ftpsetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL COMMENT 'Ten ket noi FTP',
  `description` text NOT NULL COMMENT 'Thong tin mo ta',
  `hostname` varchar(40) NOT NULL COMMENT 'IP hoac hostname cua May chu FTP',
  `path` varchar(255) NOT NULL COMMENT 'Duong dan tren may chu FTP, khong co / o truoc va sau',
  `username` varchar(40) NOT NULL COMMENT 'Thong tin dang nhap neu co',
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ftpsetting`
--

INSERT INTO `ftpsetting` (`id`, `title`, `description`, `hostname`, `path`, `username`, `password`) VALUES
(1, 'Localhost For Testing', 'Mỗi kết nối FTP tới server cho phép kết nối và lấy file từ server.', 'localhost', 'pub', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(10) DEFAULT NULL,
  `lft` int(10) NOT NULL,
  `rgt` int(10) NOT NULL,
  `level` int(5) NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  `visible` int(1) NOT NULL,
  `task` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(10) DEFAULT NULL,
  `translation` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `language`, `translation`) VALUES
(5, 'vi', 'Quản trị viên'),
(6, 'vi', 'Quản trị iSMS'),
(7, 'vi', 'Đối tác iSMS'),
(32, 'vi', 'Quản lý danh sách thuê bao từ chối nhận tin'),
(33, 'vi', 'Khai báo thuê bao đăng ký dịch vụ chặn tin nhắn'),
(36, 'vi', 'Khai báo chương trình nhắn tin mới'),
(37, 'vi', 'Xóa chương trình nhắn tin');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  `module` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migration`
--


-- --------------------------------------------------------

--
-- Table structure for table `node`
--

CREATE TABLE IF NOT EXISTS `node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `cid` int(11) DEFAULT NULL,
  `type` text,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `node`
--

INSERT INTO `node` (`id`, `title`, `alias`, `description`, `body`, `createtime`, `updatetime`, `uid`, `cid`, `type`, `status`) VALUES
(1, 'Quản lý phiên bản với Hg', 'Quan-ly-phien-ban-voi-Hg', 'iSMS sử dụng phiên bản Hg...', '<ol>\r\n	<li>\r\n		Cài đặt &nbsp;TortoiseHg.</li>\r\n	<li>\r\n		Chuột phải &gt; TortoiseHg &gt; Clone</li>\r\n	<li>\r\n		Nhập: http://172.16.16.200:8000</li>\r\n	<li>\r\n		Nhấn OK</li>\r\n</ol>\r\n<p>\r\n	TortoiseHg sẽ download code về máy.</p>\r\n<p>\r\n	Sau khi sửa tính năng, bấm phải và chọn Hg Commit.</p>\r\n<p>\r\n	Sau khi sửa nhiều tính năng và đã thấy ổn, push lên Server: Chọn Hg Push</p>\r\n', 1334824342, 1334824342, 1, NULL, 'node', 1);

-- --------------------------------------------------------

--
-- Table structure for table `node_tag`
--

CREATE TABLE IF NOT EXISTS `node_tag` (
  `nid` int(10) NOT NULL,
  `tid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE IF NOT EXISTS `organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'bearerbox_id',
  `title` varchar(255) NOT NULL COMMENT 'Ten trung tam',
  `description` text NOT NULL COMMENT 'Mo ta di kem',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`id`, `title`, `description`) VALUES
(3, 'Hà Nội', '');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `profiles`
--


-- --------------------------------------------------------

--
-- Table structure for table `profiles_fields`
--

CREATE TABLE IF NOT EXISTS `profiles_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` int(3) NOT NULL,
  `field_size_min` int(3) NOT NULL,
  `required` int(1) NOT NULL,
  `match` varchar(255) NOT NULL,
  `range` varchar(255) NOT NULL,
  `error_message` varchar(255) NOT NULL,
  `other_validator` text NOT NULL,
  `default` varchar(255) NOT NULL,
  `widget` varchar(255) NOT NULL,
  `widgetparams` text NOT NULL,
  `position` int(3) NOT NULL,
  `visible` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `profiles_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `rights`
--

CREATE TABLE IF NOT EXISTS `rights` (
  `itemname` varchar(255) NOT NULL COMMENT 'authitem.name',
  `type` int(11) NOT NULL COMMENT '0|operation, 1|task, 2|role',
  `weight` int(11) NOT NULL COMMENT 'Order',
  PRIMARY KEY (`itemname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rights`
--


-- --------------------------------------------------------

--
-- Table structure for table `send_sms`
--

CREATE TABLE IF NOT EXISTS `send_sms` (
  `momt` enum('MO','MT','DLR','3rd') DEFAULT NULL,
  `sender` varchar(20) DEFAULT NULL,
  `receiver` varchar(20) NOT NULL DEFAULT '',
  `udhdata` blob,
  `msgdata` text,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `smsc_id` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `id` bigint(20) DEFAULT NULL,
  `sms_type` bigint(20) DEFAULT NULL,
  `mclass` bigint(20) DEFAULT NULL,
  `mwi` bigint(20) DEFAULT NULL,
  `coding` bigint(20) DEFAULT NULL,
  `compress` bigint(20) DEFAULT NULL,
  `validity` bigint(20) DEFAULT NULL,
  `deferred` bigint(20) DEFAULT NULL,
  `dlr_mask` bigint(20) DEFAULT NULL,
  `dlr_url` varchar(255) DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `alt_dcs` bigint(20) DEFAULT NULL,
  `rpi` bigint(20) DEFAULT NULL,
  `charset` varchar(255) DEFAULT NULL,
  `boxc_id` varchar(255) DEFAULT NULL,
  `binfo` varchar(255) DEFAULT NULL,
  `campaign_id` int(9) NOT NULL DEFAULT '0',
  `bearerbox_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`campaign_id`,`receiver`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8
/*!50100 PARTITION BY HASH (campaign_id)
PARTITIONS 100 */;

--
-- Dumping data for table `send_sms`
--


-- --------------------------------------------------------

--
-- Table structure for table `sent_sms`
--

CREATE TABLE IF NOT EXISTS `sent_sms` (
  `momt` enum('MO','MT','DLR','3rd') DEFAULT NULL,
  `sender` varchar(20) DEFAULT NULL,
  `receiver` varchar(20) NOT NULL DEFAULT '',
  `udhdata` blob,
  `msgdata` text,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `smsc_id` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `id` bigint(20) DEFAULT NULL,
  `sms_type` bigint(20) DEFAULT NULL,
  `mclass` bigint(20) DEFAULT NULL,
  `mwi` bigint(20) DEFAULT NULL,
  `coding` bigint(20) DEFAULT NULL,
  `compress` bigint(20) DEFAULT NULL,
  `validity` bigint(20) DEFAULT NULL,
  `deferred` bigint(20) DEFAULT NULL,
  `dlr_mask` bigint(20) DEFAULT NULL,
  `dlr_url` varchar(255) DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `alt_dcs` bigint(20) DEFAULT NULL,
  `rpi` bigint(20) DEFAULT NULL,
  `charset` varchar(255) DEFAULT NULL,
  `boxc_id` varchar(255) DEFAULT NULL,
  `binfo` varchar(255) DEFAULT NULL,
  `campaign_id` int(9) NOT NULL DEFAULT '0',
  `bearerbox_id` varchar(20) DEFAULT NULL,
  KEY `campaign_id` (`campaign_id`),
  KEY `receiver` (`receiver`),
  KEY `sender` (`sender`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8
/*!50100 PARTITION BY HASH (campaign_id)
PARTITIONS 100 */;

--
-- Dumping data for table `sent_sms`
--


-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `category` varchar(64) NOT NULL DEFAULT 'system',
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`category`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`category`, `key`, `value`) VALUES
('Webtheme', 'contactEmail', 's:0:"";'),
('Webtheme', 'homeUrl', 's:9:"/cms/node";'),
('Webtheme', 'layout', 's:17:"//layouts/column2";'),
('Webtheme', 'perPage', 's:2:"20";'),
('Webtheme', 'serverEmail', 's:0:"";'),
('Webtheme', 'siteLogo', 's:0:"";'),
('Webtheme', 'siteName', 's:4:"iSMS";'),
('Webtheme', 'siteSlogan', 's:0:"";'),
('Webtheme', 'theme', 's:13:"shadow_dancer";');

-- --------------------------------------------------------

--
-- Table structure for table `smsorder`
--

CREATE TABLE IF NOT EXISTS `smsorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `userid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `updatetime` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `expired` datetime NOT NULL,
  `smscount` bigint(20) NOT NULL,
  `smsleft` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `smsorder`
--

INSERT INTO `smsorder` (`id`, `title`, `description`, `userid`, `createtime`, `updatetime`, `status`, `expired`, `smscount`, `smsleft`) VALUES
(2, 'ISTT Quota 2', 'Đây cũng là một đơn hàng cho ISTT...', 1, 1334545743, 1334545743, 1, '2012-04-25 00:00:00', 20000, 0),
(3, 'ISTT Quota3', 'THu nghiem tinh nang...', 2, 1335928572, 1335928572, 1, '2012-05-02 14:00:00', 9000, 9000);

-- --------------------------------------------------------

--
-- Table structure for table `sourcemessage`
--

CREATE TABLE IF NOT EXISTS `sourcemessage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(32) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=264 ;

--
-- Dumping data for table `sourcemessage`
--

INSERT INTO `sourcemessage` (`id`, `category`, `message`) VALUES
(5, 'rights', 'Admin'),
(6, 'rights', 'iSMS Admin'),
(7, 'rights', 'iSMS Partner'),
(8, 'rights', 'Cms.Category.Admin'),
(9, 'rights', 'Cms.Tags.Admin'),
(10, 'rights', 'Cms.Tags.Delete'),
(11, 'rights', 'Cms.Tags.Update'),
(12, 'rights', 'Cms.Webmenu.Admin'),
(13, 'rights', 'Core.Block.Admin'),
(14, 'rights', 'Core.Block.Configure'),
(15, 'rights', 'Core.Block.Create'),
(16, 'rights', 'Core.Block.Delete'),
(17, 'rights', 'Core.Block.Duplicate'),
(18, 'rights', 'Core.Block.Theme'),
(19, 'rights', 'Core.Block.Update'),
(20, 'rights', 'Core.Block.View'),
(21, 'rights', 'Core.Blocktype.Admin'),
(22, 'rights', 'Core.Blocktype.Clone'),
(23, 'rights', 'Core.Blocktype.Create'),
(24, 'rights', 'Core.Blocktype.Delete'),
(25, 'rights', 'Core.Blocktype.Duplicate'),
(26, 'rights', 'Core.Blocktype.Update'),
(27, 'rights', 'Core.Blocktype.View'),
(28, 'rights', 'Core.Log.Admin'),
(29, 'rights', 'Core.Log.Delete'),
(30, 'rights', 'Core.Webtheme.Index'),
(31, 'rights', 'Core.Webtheme.View'),
(32, 'rights', 'Isms.Blacklist.Admin'),
(33, 'rights', 'Isms.Blacklist.Create'),
(34, 'rights', 'Isms.Blacklist.Delete'),
(35, 'rights', 'Isms.Blacklist.Update'),
(36, 'rights', 'Isms.Campaign.Create'),
(37, 'rights', 'Isms.Campaign.Delete'),
(38, 'rights', 'Isms.Campaign.Index'),
(39, 'rights', 'Isms.Campaign.Update'),
(40, 'rights', 'Isms.Campaign.Upload'),
(41, 'rights', 'Isms.Campaign.View'),
(42, 'rights', 'Isms.Cpfile.Admin'),
(43, 'rights', 'Isms.Cpfile.Create'),
(44, 'rights', 'Isms.Cpfile.Delete'),
(45, 'rights', 'Isms.Cpfile.Update'),
(46, 'rights', 'Isms.Cpfilter.Admin'),
(47, 'rights', 'Isms.Cpfilter.Create'),
(48, 'rights', 'Isms.Cpfilter.Delete'),
(49, 'rights', 'Isms.Cpfilter.Update'),
(50, 'rights', 'Isms.Cpworktime.Admin'),
(51, 'rights', 'Isms.Cpworktime.Create'),
(52, 'rights', 'Isms.Cpworktime.Delete'),
(53, 'rights', 'Isms.Cpworktime.Update'),
(54, 'rights', 'Isms.Dailyreport.Admin'),
(55, 'rights', 'Isms.Dailyreport.Create'),
(56, 'rights', 'Isms.Dailyreport.Delete'),
(57, 'rights', 'Isms.Dailyreport.Update'),
(58, 'rights', 'Isms.Datafile.Admin'),
(59, 'rights', 'Isms.Datafile.Create'),
(60, 'rights', 'Isms.Datafile.Delete'),
(61, 'rights', 'Isms.Datafile.Update'),
(62, 'rights', 'Isms.Datafile.View'),
(63, 'rights', 'Isms.Emailsetting.Admin'),
(64, 'rights', 'Isms.Emailsetting.Create'),
(65, 'rights', 'Isms.Emailsetting.Delete'),
(66, 'rights', 'Isms.Emailsetting.Update'),
(67, 'rights', 'Isms.Emailsetting.View'),
(68, 'rights', 'Isms.Filter.Blacklist'),
(69, 'rights', 'Isms.Filter.Create'),
(70, 'rights', 'Isms.Filter.Delete'),
(71, 'rights', 'Isms.Filter.Index'),
(72, 'rights', 'Isms.Filter.Update'),
(73, 'rights', 'Isms.Filter.View'),
(74, 'rights', 'Isms.Filter.Whitelist'),
(75, 'rights', 'Isms.Ftpfilename.Admin'),
(76, 'rights', 'Isms.Ftpfilename.Create'),
(77, 'rights', 'Isms.Ftpfilename.Delete'),
(78, 'rights', 'Isms.Ftpfilename.Update'),
(79, 'rights', 'Isms.Ftpsetting.Admin'),
(80, 'rights', 'Isms.Ftpsetting.Create'),
(81, 'rights', 'Isms.Ftpsetting.Delete'),
(82, 'rights', 'Isms.Ftpsetting.Update'),
(83, 'rights', 'Isms.Organization.Admin'),
(84, 'rights', 'Isms.Organization.Create'),
(85, 'rights', 'Isms.Organization.Delete'),
(86, 'rights', 'Isms.Organization.Update'),
(87, 'rights', 'Isms.Organization.View'),
(88, 'rights', 'Isms.Sendsms.Admin'),
(89, 'rights', 'Isms.Sendsms.Create'),
(90, 'rights', 'Isms.Sendsms.Delete'),
(91, 'rights', 'Isms.Sendsms.Update'),
(92, 'rights', 'Isms.SentSms.Admin'),
(93, 'rights', 'Isms.SentSms.Create'),
(94, 'rights', 'Isms.SentSms.Delete'),
(95, 'rights', 'Isms.SentSms.Update'),
(96, 'rights', 'Isms.Smsorder.Admin'),
(97, 'rights', 'Isms.Smsorder.Create'),
(98, 'rights', 'Isms.Smsorder.Delete'),
(99, 'rights', 'Isms.Smsorder.Update'),
(100, 'rights', 'Isms.Smsorder.View'),
(101, 'rights', 'Isms.Syntax.Admin'),
(102, 'rights', 'Isms.Syntax.Create'),
(103, 'rights', 'Isms.Syntax.Delete'),
(104, 'rights', 'Isms.Syntax.Update'),
(105, 'rights', 'Isms.Template.Admin'),
(106, 'rights', 'Isms.Template.Create'),
(107, 'rights', 'Isms.Template.Delete'),
(108, 'rights', 'Isms.Template.Update'),
(109, 'rights', 'Isms.Whitelist.Admin'),
(110, 'rights', 'Isms.Whitelist.Create'),
(111, 'rights', 'Isms.Whitelist.Delete'),
(112, 'rights', 'Isms.Whitelist.Update'),
(113, 'rights', 'Isms.Worktime.Admin'),
(114, 'rights', 'Isms.Worktime.Create'),
(115, 'rights', 'Isms.Worktime.Delete'),
(116, 'rights', 'Isms.Worktime.Update'),
(117, 'rights', 'User.Admin.Admin'),
(118, 'rights', 'User.Admin.Create'),
(119, 'rights', 'User.Admin.Delete'),
(120, 'rights', 'User.Admin.Update'),
(121, 'rights', 'User.Admin.View'),
(122, 'rights', 'Cms.Category.*'),
(123, 'rights', 'Cms.Node.*'),
(124, 'rights', 'Cms.Tags.*'),
(125, 'rights', 'Cms.Webmenu.*'),
(126, 'rights', 'Core.Block.*'),
(127, 'rights', 'Core.Blocktype.*'),
(128, 'rights', 'Core.Log.*'),
(129, 'rights', 'Core.Webtheme.*'),
(130, 'rights', 'Isms.Blacklist.*'),
(131, 'rights', 'Isms.Campaign.*'),
(132, 'rights', 'Isms.Cpfile.*'),
(133, 'rights', 'Isms.Cpfilter.*'),
(134, 'rights', 'Isms.Cpworktime.*'),
(135, 'rights', 'Isms.Dailyreport.*'),
(136, 'rights', 'Isms.Datafile.*'),
(137, 'rights', 'Isms.Emailsetting.*'),
(138, 'rights', 'Isms.Filter.*'),
(139, 'rights', 'Isms.Ftpfilename.*'),
(140, 'rights', 'Isms.Ftpsetting.*'),
(141, 'rights', 'Isms.Organization.*'),
(142, 'rights', 'Isms.Sendsms.*'),
(143, 'rights', 'Isms.SentSms.*'),
(144, 'rights', 'Isms.Smsorder.*'),
(145, 'rights', 'Isms.Syntax.*'),
(146, 'rights', 'Isms.Template.*'),
(147, 'rights', 'Isms.Whitelist.*'),
(148, 'rights', 'Isms.Worktime.*'),
(149, 'rights', 'User.Admin.*'),
(150, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Cms.Category.Admin">Cms.Category.Admin</a> <span class="auth-item-name" style="display:none;">Cms.Category.Admin</span>'),
(151, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Cms.Tags.Admin">Cms.Tags.Admin</a> <span class="auth-item-name" style="display:none;">Cms.Tags.Admin</span>'),
(152, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Cms.Tags.Delete">Cms.Tags.Delete</a> <span class="auth-item-name" style="display:none;">Cms.Tags.Delete</span>'),
(153, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Cms.Tags.Update">Cms.Tags.Update</a> <span class="auth-item-name" style="display:none;">Cms.Tags.Update</span>'),
(154, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Cms.Webmenu.Admin">Cms.Webmenu.Admin</a> <span class="auth-item-name" style="display:none;">Cms.Webmenu.Admin</span>'),
(155, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Admin">Core.Block.Admin</a> <span class="auth-item-name" style="display:none;">Core.Block.Admin</span>'),
(156, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Configure">Core.Block.Configure</a> <span class="auth-item-name" style="display:none;">Core.Block.Configure</span>'),
(157, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Create">Core.Block.Create</a> <span class="auth-item-name" style="display:none;">Core.Block.Create</span>'),
(158, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Delete">Core.Block.Delete</a> <span class="auth-item-name" style="display:none;">Core.Block.Delete</span>'),
(159, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Duplicate">Core.Block.Duplicate</a> <span class="auth-item-name" style="display:none;">Core.Block.Duplicate</span>'),
(160, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Theme">Core.Block.Theme</a> <span class="auth-item-name" style="display:none;">Core.Block.Theme</span>'),
(161, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.Update">Core.Block.Update</a> <span class="auth-item-name" style="display:none;">Core.Block.Update</span>'),
(162, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Block.View">Core.Block.View</a> <span class="auth-item-name" style="display:none;">Core.Block.View</span>'),
(163, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.Admin">Core.Blocktype.Admin</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.Admin</span>'),
(164, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.Clone">Core.Blocktype.Clone</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.Clone</span>'),
(165, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.Create">Core.Blocktype.Create</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.Create</span>'),
(166, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.Delete">Core.Blocktype.Delete</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.Delete</span>'),
(167, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.Duplicate">Core.Blocktype.Duplicate</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.Duplicate</span>'),
(168, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.Update">Core.Blocktype.Update</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.Update</span>'),
(169, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Blocktype.View">Core.Blocktype.View</a> <span class="auth-item-name" style="display:none;">Core.Blocktype.View</span>'),
(170, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Log.Admin">Core.Log.Admin</a> <span class="auth-item-name" style="display:none;">Core.Log.Admin</span>'),
(171, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Log.Delete">Core.Log.Delete</a> <span class="auth-item-name" style="display:none;">Core.Log.Delete</span>'),
(172, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Webtheme.Index">Core.Webtheme.Index</a> <span class="auth-item-name" style="display:none;">Core.Webtheme.Index</span>'),
(173, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Core.Webtheme.View">Core.Webtheme.View</a> <span class="auth-item-name" style="display:none;">Core.Webtheme.View</span>'),
(174, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Blacklist.Admin">Isms.Blacklist.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Blacklist.Admin</span>'),
(175, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Blacklist.Create">Isms.Blacklist.Create</a> <span class="auth-item-name" style="display:none;">Isms.Blacklist.Create</span>'),
(176, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Blacklist.Delete">Isms.Blacklist.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Blacklist.Delete</span>'),
(177, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Blacklist.Update">Isms.Blacklist.Update</a> <span class="auth-item-name" style="display:none;">Isms.Blacklist.Update</span>'),
(178, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Campaign.Create">Isms.Campaign.Create</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">Isms.Campaign.Create</span>'),
(179, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Campaign.Delete">Isms.Campaign.Delete</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">Isms.Campaign.Delete</span>'),
(180, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Campaign.Index">Isms.Campaign.Index</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">Isms.Campaign.Index</span>'),
(181, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Campaign.Update">Isms.Campaign.Update</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">Isms.Campaign.Update</span>'),
(182, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Campaign.Upload">Isms.Campaign.Upload</a> <span class="auth-item-name" style="display:none;">Isms.Campaign.Upload</span>'),
(183, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Campaign.View">Isms.Campaign.View</a> [ <span class="child-count">12</span> ] <span class="auth-item-name" style="display:none;">Isms.Campaign.View</span>'),
(184, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfile.Admin">Isms.Cpfile.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Cpfile.Admin</span>'),
(185, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfile.Create">Isms.Cpfile.Create</a> <span class="auth-item-name" style="display:none;">Isms.Cpfile.Create</span>'),
(186, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfile.Delete">Isms.Cpfile.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Cpfile.Delete</span>'),
(187, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfile.Update">Isms.Cpfile.Update</a> <span class="auth-item-name" style="display:none;">Isms.Cpfile.Update</span>'),
(188, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfilter.Admin">Isms.Cpfilter.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Cpfilter.Admin</span>'),
(189, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfilter.Create">Isms.Cpfilter.Create</a> <span class="auth-item-name" style="display:none;">Isms.Cpfilter.Create</span>'),
(190, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfilter.Delete">Isms.Cpfilter.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Cpfilter.Delete</span>'),
(191, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpfilter.Update">Isms.Cpfilter.Update</a> <span class="auth-item-name" style="display:none;">Isms.Cpfilter.Update</span>'),
(192, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpworktime.Admin">Isms.Cpworktime.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Cpworktime.Admin</span>'),
(193, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpworktime.Create">Isms.Cpworktime.Create</a> <span class="auth-item-name" style="display:none;">Isms.Cpworktime.Create</span>'),
(194, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpworktime.Delete">Isms.Cpworktime.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Cpworktime.Delete</span>'),
(195, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Cpworktime.Update">Isms.Cpworktime.Update</a> <span class="auth-item-name" style="display:none;">Isms.Cpworktime.Update</span>'),
(196, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Dailyreport.Admin">Isms.Dailyreport.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Dailyreport.Admin</span>'),
(197, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Dailyreport.Create">Isms.Dailyreport.Create</a> <span class="auth-item-name" style="display:none;">Isms.Dailyreport.Create</span>'),
(198, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Dailyreport.Delete">Isms.Dailyreport.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Dailyreport.Delete</span>'),
(199, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Dailyreport.Update">Isms.Dailyreport.Update</a> <span class="auth-item-name" style="display:none;">Isms.Dailyreport.Update</span>'),
(200, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Datafile.Admin">Isms.Datafile.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Datafile.Admin</span>'),
(201, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Datafile.Create">Isms.Datafile.Create</a> <span class="auth-item-name" style="display:none;">Isms.Datafile.Create</span>'),
(202, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Datafile.Delete">Isms.Datafile.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Datafile.Delete</span>'),
(203, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Datafile.Update">Isms.Datafile.Update</a> <span class="auth-item-name" style="display:none;">Isms.Datafile.Update</span>'),
(204, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Datafile.View">Isms.Datafile.View</a> <span class="auth-item-name" style="display:none;">Isms.Datafile.View</span>'),
(205, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Emailsetting.Admin">Isms.Emailsetting.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Emailsetting.Admin</span>'),
(206, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Emailsetting.Create">Isms.Emailsetting.Create</a> <span class="auth-item-name" style="display:none;">Isms.Emailsetting.Create</span>'),
(207, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Emailsetting.Delete">Isms.Emailsetting.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Emailsetting.Delete</span>'),
(208, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Emailsetting.Update">Isms.Emailsetting.Update</a> <span class="auth-item-name" style="display:none;">Isms.Emailsetting.Update</span>'),
(209, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Emailsetting.View">Isms.Emailsetting.View</a> <span class="auth-item-name" style="display:none;">Isms.Emailsetting.View</span>'),
(210, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.Blacklist">Isms.Filter.Blacklist</a> <span class="auth-item-name" style="display:none;">Isms.Filter.Blacklist</span>'),
(211, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.Create">Isms.Filter.Create</a> <span class="auth-item-name" style="display:none;">Isms.Filter.Create</span>'),
(212, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.Delete">Isms.Filter.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Filter.Delete</span>'),
(213, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.Index">Isms.Filter.Index</a> <span class="auth-item-name" style="display:none;">Isms.Filter.Index</span>'),
(214, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.Update">Isms.Filter.Update</a> <span class="auth-item-name" style="display:none;">Isms.Filter.Update</span>'),
(215, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.View">Isms.Filter.View</a> <span class="auth-item-name" style="display:none;">Isms.Filter.View</span>'),
(216, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Filter.Whitelist">Isms.Filter.Whitelist</a> <span class="auth-item-name" style="display:none;">Isms.Filter.Whitelist</span>'),
(217, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpfilename.Admin">Isms.Ftpfilename.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Ftpfilename.Admin</span>'),
(218, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpfilename.Create">Isms.Ftpfilename.Create</a> <span class="auth-item-name" style="display:none;">Isms.Ftpfilename.Create</span>'),
(219, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpfilename.Delete">Isms.Ftpfilename.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Ftpfilename.Delete</span>'),
(220, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpfilename.Update">Isms.Ftpfilename.Update</a> <span class="auth-item-name" style="display:none;">Isms.Ftpfilename.Update</span>'),
(221, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpsetting.Admin">Isms.Ftpsetting.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Ftpsetting.Admin</span>'),
(222, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpsetting.Create">Isms.Ftpsetting.Create</a> <span class="auth-item-name" style="display:none;">Isms.Ftpsetting.Create</span>'),
(223, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpsetting.Delete">Isms.Ftpsetting.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Ftpsetting.Delete</span>'),
(224, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Ftpsetting.Update">Isms.Ftpsetting.Update</a> <span class="auth-item-name" style="display:none;">Isms.Ftpsetting.Update</span>'),
(225, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Organization.Admin">Isms.Organization.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Organization.Admin</span>'),
(226, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Organization.Create">Isms.Organization.Create</a> <span class="auth-item-name" style="display:none;">Isms.Organization.Create</span>'),
(227, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Organization.Delete">Isms.Organization.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Organization.Delete</span>'),
(228, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Organization.Update">Isms.Organization.Update</a> <span class="auth-item-name" style="display:none;">Isms.Organization.Update</span>'),
(229, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Organization.View">Isms.Organization.View</a> <span class="auth-item-name" style="display:none;">Isms.Organization.View</span>'),
(230, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Sendsms.Admin">Isms.Sendsms.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Sendsms.Admin</span>'),
(231, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Sendsms.Create">Isms.Sendsms.Create</a> <span class="auth-item-name" style="display:none;">Isms.Sendsms.Create</span>'),
(232, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Sendsms.Delete">Isms.Sendsms.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Sendsms.Delete</span>'),
(233, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Sendsms.Update">Isms.Sendsms.Update</a> <span class="auth-item-name" style="display:none;">Isms.Sendsms.Update</span>'),
(234, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.SentSms.Admin">Isms.SentSms.Admin</a> <span class="auth-item-name" style="display:none;">Isms.SentSms.Admin</span>'),
(235, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.SentSms.Create">Isms.SentSms.Create</a> <span class="auth-item-name" style="display:none;">Isms.SentSms.Create</span>'),
(236, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.SentSms.Delete">Isms.SentSms.Delete</a> <span class="auth-item-name" style="display:none;">Isms.SentSms.Delete</span>'),
(237, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.SentSms.Update">Isms.SentSms.Update</a> <span class="auth-item-name" style="display:none;">Isms.SentSms.Update</span>'),
(238, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Smsorder.Admin">Isms.Smsorder.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Smsorder.Admin</span>'),
(239, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Smsorder.Create">Isms.Smsorder.Create</a> <span class="auth-item-name" style="display:none;">Isms.Smsorder.Create</span>'),
(240, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Smsorder.Delete">Isms.Smsorder.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Smsorder.Delete</span>'),
(241, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Smsorder.Update">Isms.Smsorder.Update</a> <span class="auth-item-name" style="display:none;">Isms.Smsorder.Update</span>'),
(242, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Smsorder.View">Isms.Smsorder.View</a> <span class="auth-item-name" style="display:none;">Isms.Smsorder.View</span>'),
(243, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Syntax.Admin">Isms.Syntax.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Syntax.Admin</span>'),
(244, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Syntax.Create">Isms.Syntax.Create</a> <span class="auth-item-name" style="display:none;">Isms.Syntax.Create</span>'),
(245, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Syntax.Delete">Isms.Syntax.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Syntax.Delete</span>'),
(246, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Syntax.Update">Isms.Syntax.Update</a> <span class="auth-item-name" style="display:none;">Isms.Syntax.Update</span>'),
(247, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Template.Admin">Isms.Template.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Template.Admin</span>'),
(248, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Template.Create">Isms.Template.Create</a> <span class="auth-item-name" style="display:none;">Isms.Template.Create</span>'),
(249, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Template.Delete">Isms.Template.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Template.Delete</span>'),
(250, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Template.Update">Isms.Template.Update</a> <span class="auth-item-name" style="display:none;">Isms.Template.Update</span>'),
(251, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Whitelist.Admin">Isms.Whitelist.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Whitelist.Admin</span>'),
(252, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Whitelist.Create">Isms.Whitelist.Create</a> <span class="auth-item-name" style="display:none;">Isms.Whitelist.Create</span>'),
(253, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Whitelist.Delete">Isms.Whitelist.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Whitelist.Delete</span>'),
(254, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Whitelist.Update">Isms.Whitelist.Update</a> <span class="auth-item-name" style="display:none;">Isms.Whitelist.Update</span>'),
(255, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Worktime.Admin">Isms.Worktime.Admin</a> <span class="auth-item-name" style="display:none;">Isms.Worktime.Admin</span>'),
(256, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Worktime.Create">Isms.Worktime.Create</a> <span class="auth-item-name" style="display:none;">Isms.Worktime.Create</span>'),
(257, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Worktime.Delete">Isms.Worktime.Delete</a> <span class="auth-item-name" style="display:none;">Isms.Worktime.Delete</span>'),
(258, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/Isms.Worktime.Update">Isms.Worktime.Update</a> <span class="auth-item-name" style="display:none;">Isms.Worktime.Update</span>'),
(259, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/User.Admin.Admin">User.Admin.Admin</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">User.Admin.Admin</span>'),
(260, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/User.Admin.Create">User.Admin.Create</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">User.Admin.Create</span>'),
(261, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/User.Admin.Delete">User.Admin.Delete</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">User.Admin.Delete</span>'),
(262, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/User.Admin.Update">User.Admin.Update</a> [ <span class="child-count">1</span> ] <span class="auth-item-name" style="display:none;">User.Admin.Update</span>'),
(263, 'rights', '<a href="/isms/index.php/rights/authItem/update/name/User.Admin.View">User.Admin.View</a> <span class="auth-item-name" style="display:none;">User.Admin.View</span>');

-- --------------------------------------------------------

--
-- Table structure for table `syntax`
--

CREATE TABLE IF NOT EXISTS `syntax` (
  `fid` int(11) NOT NULL,
  `syntax` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`fid`,`syntax`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `syntax`
--

INSERT INTO `syntax` (`fid`, `syntax`, `type`) VALUES
(1, 'DANG KY', 1),
(1, 'TU CHOI', 0),
(2, 'DANGKY ISTT', 1),
(2, 'TUCHOI ISTT', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `frequency` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `template`
--

CREATE TABLE IF NOT EXISTS `template` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) DEFAULT '',
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`id`, `title`, `body`) VALUES
(3, 'SMS1', 'Nội dung thứ nhất...'),
(4, 'SMS2', 'Nội dung thứ hai...'),
(5, 'SMS3', 'Đây cũng là nội dung tin nhắn...');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL,
  `createtime` int(10) NOT NULL,
  `lastvisit` int(10) NOT NULL,
  `role` varchar(200) NOT NULL,
  `status` int(1) NOT NULL,
  `org` int(11) NOT NULL,
  `sender` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activkey`, `createtime`, `lastvisit`, `role`, `status`, `org`, `sender`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'nguyendinhtrung141@gmail.com', '5c76328f742710a9bd436d0ada4109e9', 1334544370, 1336030706, '', 1, 0, ''),
(2, 'istt', 'e10adc3949ba59abbe56e057f20f883e', 'contact@istt.com.vn', 'c0977ab8e67ae3f63845b14af20f9e76', 1334545682, 1334545682, 'iSMS Partner', 1, 3, 'ISTT'),
(3, 'ddhieu', 'e10adc3949ba59abbe56e057f20f883e', 'ddhieu@istt.com.vn', '186939a3e19f905ae6ed9ba2af0d8d3a', 1336031762, 1336031762, 'iSMS Admin', 1, 3, 'DDHIEU');

-- --------------------------------------------------------

--
-- Table structure for table `whitelist`
--

CREATE TABLE IF NOT EXISTS `whitelist` (
  `fid` int(11) NOT NULL,
  `isdn` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`,`isdn`),
  KEY `phonenumber` (`isdn`),
  KEY `fid` (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `whitelist`
--


-- --------------------------------------------------------

--
-- Table structure for table `worktime`
--

CREATE TABLE IF NOT EXISTS `worktime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` time NOT NULL,
  `end` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `worktime`
--

INSERT INTO `worktime` (`id`, `start`, `end`) VALUES
(6, '01:00:00', '22:00:00'),
(7, '03:00:00', '06:18:00'),
(8, '03:00:00', '16:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `yiilog`
--

CREATE TABLE IF NOT EXISTS `yiilog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(128) DEFAULT NULL,
  `category` varchar(128) DEFAULT NULL,
  `logtime` int(11) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `yiilog`
--

INSERT INTO `yiilog` (`id`, `level`, `category`, `logtime`, `message`) VALUES
(12, 'error', 'exception.CHttpException.404', 1334543896, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(13, 'error', 'exception.CHttpException.404', 1334544088, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(14, 'error', 'exception.CHttpException.404', 1334544100, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(15, 'error', 'exception.CHttpException.404', 1334544122, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(16, 'error', 'exception.CHttpException.404', 1334544133, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(17, 'error', 'exception.CHttpException.404', 1334544141, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(18, 'error', 'exception.CHttpException.404', 1334544158, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "core/node".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''core/node'')\n#1 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''core/node'')\n#2 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#12 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#13 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#14 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#15 {main}\nREQUEST_URI=/isms/\n---'),
(19, 'error', 'exception.CHttpException.403', 1334544389, 'exception ''CHttpException'' with message ''You are not authorized to perform this action.'' in D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php:136\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\rights\\components\\RightsFilter.php(57): WebBaseController->accessDenied()\n#1 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(39): RightsFilter->preFilter(Object(CFilterChain))\n#2 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#5 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#8 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''core/webtheme'')\n#9 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#10 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#11 {main}\nREQUEST_URI=/isms/index.php/core/webtheme\n---'),
(20, 'error', 'exception.CHttpException.403', 1334544476, 'exception ''CHttpException'' with message ''You are not authorized to perform this action.'' in D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php:136\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\rights\\components\\RightsFilter.php(57): WebBaseController->accessDenied()\n#1 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(39): RightsFilter->preFilter(Object(CFilterChain))\n#2 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#5 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#8 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''core/webtheme'')\n#9 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#10 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#11 {main}\nREQUEST_URI=/isms/index.php/core/webtheme\n---'),
(21, 'error', 'exception.CHttpException.403', 1334544588, 'exception ''CHttpException'' with message ''You are not authorized to perform this action.'' in D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php:136\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\rights\\components\\RightsFilter.php(57): WebBaseController->accessDenied()\n#1 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(39): RightsFilter->preFilter(Object(CFilterChain))\n#2 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#5 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#8 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''core/webtheme'')\n#9 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#10 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#11 {main}\nREQUEST_URI=/isms/index.php/core/webtheme\n---'),
(22, 'error', 'php', 1334545407, 'Undefined variable: modelClass (D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\organization\\_menu.php:11)\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): OrganizationController->renderFile()\n#1 D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\organization\\view.php(6): OrganizationController->renderPartial()\n#2 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require()\n#3 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): OrganizationController->renderInternal()\n#4 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): OrganizationController->renderFile()\n#5 D:\\wamp\\www\\yiiframework\\web\\CController.php(783): OrganizationController->renderPartial()\n#6 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(155): OrganizationController->render()\n#7 D:\\wamp\\www\\isms\\protected\\extensions\\actions\\ViewAction.php(30): OrganizationController->render()\n#8 D:\\wamp\\www\\isms\\protected\\extensions\\actions\\BaseAction.php(60): ViewAction->render()\n#9 D:\\wamp\\www\\yiiframework\\web\\actions\\CAction.php(75): ViewAction->run()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): ViewAction->runWithParams()\n#11 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): OrganizationController->runAction()\n#12 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#13 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): RightsFilter->filter()\n#14 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): OrganizationController->filterRights()\n#15 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter()\n#16 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#17 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): OrganizationController->runActionWithFilters()\n#18 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): OrganizationController->run()\n#19 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController()\n#20 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#21 D:\\wamp\\www\\isms\\index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/organization/view/id/3\nin D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\organization\\_menu.php (11)\nin D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\organization\\view.php (6)\nin D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php (155)\nin D:\\wamp\\www\\isms\\protected\\extensions\\actions\\ViewAction.php (30)\nin D:\\wamp\\www\\isms\\protected\\extensions\\actions\\BaseAction.php (60)\nin D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php (104)\nin D:\\wamp\\www\\isms\\index.php (21)'),
(23, 'info', 'application', 1334545652, 'Message  could not be added to messageSource table\nin D:\\wamp\\www\\isms\\protected\\modules\\translate\\components\\MPTranslate.php (76)\nin D:\\wamp\\www\\isms\\protected\\modules\\translate\\TranslateModule.php (39)\nin D:\\wamp\\www\\isms\\themes\\shadow_dancer\\views\\user\\admin\\index.php (41)\nin D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php (155)\nin D:\\wamp\\www\\isms\\protected\\modules\\user\\controllers\\AdminController.php (15)\nin D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php (104)\nin D:\\wamp\\www\\isms\\index.php (21)'),
(24, 'error', 'system.db.CDbCommand', 1334547182, 'CDbCommand::fetchAll() failed: SQLSTATE[42S02]: Base table or view not found: 1146 Table ''yii_isms.send_sms_135'' doesn''t exist. The SQL statement executed was: SHOW COLUMNS FROM `send_sms_135`.\nin D:\\wamp\\www\\isms\\protected\\modules\\isms\\models\\SendSms.php (44)\nin D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\CampaignController.php (17)\nin D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php (104)\nin D:\\wamp\\www\\isms\\index.php (21)'),
(25, 'error', 'exception.CDbException', 1334547182, 'exception ''CDbException'' with message ''Bảng "send_sms_135" dùng cho lớp active record "SendSms" không có trong database.'' in D:\\wamp\\www\\yiiframework\\db\\ar\\CActiveRecord.php:2264\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\db\\ar\\CActiveRecord.php(379): CActiveRecordMetaData->__construct(Object(SendSms))\n#1 D:\\wamp\\www\\yiiframework\\db\\ar\\CActiveRecord.php(394): CActiveRecord::model(''SendSms'')\n#2 D:\\wamp\\www\\yiiframework\\db\\ar\\CActiveRecord.php(78): CActiveRecord->getMetaData()\n#3 D:\\wamp\\www\\isms\\protected\\modules\\isms\\models\\SendSms.php(44): CActiveRecord->__construct(''search'')\n#4 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\CampaignController.php(17): SendSms->__construct(''search'')\n#5 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): CampaignController->actionView()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#8 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#9 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#10 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#11 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#12 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#13 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#14 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#15 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/campaign/v...'')\n#16 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#17 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#18 {main}\nREQUEST_URI=/isms/index.php/isms/campaign/view/id/135\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/campaign/create\n---'),
(26, 'error', 'exception.CException', 1334547272, 'exception ''CException'' with message ''Thuộc tính "SendSms.sql_id" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\db\\ar\\CActiveRecord.php(144): CComponent->__get(''sql_id'')\n#1 D:\\wamp\\www\\isms\\protected\\modules\\isms\\models\\SendSms.php(146): CActiveRecord->__get(''sql_id'')\n#2 D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\campaign\\view.php(149): SendSms->search()\n#3 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#4 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', Array, true)\n#5 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', Array, true)\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(783): CController->renderPartial(''view'', Array, true)\n#7 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(155): CController->render(''view'', Array, false)\n#8 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\CampaignController.php(24): WebBaseController->render(''view'', Array)\n#9 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): CampaignController->actionView()\n#10 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#11 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#12 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#13 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#14 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#15 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#16 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#17 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#18 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#19 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/campaign/v...'')\n#20 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#21 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#22 {main}\nREQUEST_URI=/isms/index.php/isms/campaign/view/id/135\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/campaign/create\n---'),
(27, 'error', 'exception.CHttpException.404', 1334548317, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in D:\\wamp\\www\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/worktime/v...'')\n#3 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/worktime/view/id/6\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/worktime/create\n---'),
(28, 'error', 'exception.CHttpException.404', 1334548941, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in D:\\wamp\\www\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ftpsetting...'')\n#3 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/ftpsetting/view/id/1\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/ftpsetting/index\n---'),
(29, 'error', 'exception.CHttpException.404', 1334549006, 'exception ''CHttpException'' with message ''The requested page does not exist.'' in D:\\wamp\\www\\isms\\protected\\extensions\\actions\\UpdateAction.php:53\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\extensions\\actions\\BaseAction.php(50): UpdateAction->model()\n#1 D:\\wamp\\www\\yiiframework\\web\\actions\\CAction.php(75): BaseAction->run()\n#2 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CAction->runWithParams(Array)\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(UpdateAction))\n#4 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#5 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#6 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(UpdateAction), Array)\n#10 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''update'')\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ftpsetting...'')\n#12 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#13 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#14 {main}\nREQUEST_URI=/isms/index.php/isms/ftpsetting/update\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/ftpsetting/update/id/1\n---');

-- --------------------------------------------------------

--
-- Table structure for table `YiiLog`
--

CREATE TABLE IF NOT EXISTS `YiiLog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(128) DEFAULT NULL,
  `category` varchar(128) DEFAULT NULL,
  `logtime` int(11) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `YiiLog`
--

INSERT INTO `YiiLog` (`id`, `level`, `category`, `logtime`, `message`) VALUES
(1, 'error', 'system.db.CDbCommand', 1334815307, 'CDbCommand::execute() failed: SQLSTATE[42S02]: Base table or view not found: 1146 Table ''yii_isms.YiiLog'' doesn''t exist. The SQL statement executed was: DELETE FROM YiiLog WHERE 0=1.\nin /var/www/html/isms/index.php (21)'),
(2, 'error', 'exception.CException', 1334826787, 'exception ''CException'' with message ''CAssetManager.basePath "D:\\wamp\\www\\isms\\assets" không hợp lệ. Hãy chắc rằng thư mục này có tồn tại và được phép ghi bởi Web server.'' in D:\\wamp\\www\\yiiframework\\web\\CAssetManager.php:116\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CAssetManager.php(101): CAssetManager->setBasePath(''D:\\wamp\\www\\ism...'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CAssetManager.php(219): CAssetManager->getBasePath()\n#2 D:\\wamp\\www\\yiiframework\\zii\\widgets\\CListView.php(179): CAssetManager->publish(''D:\\wamp\\www\\yii...'')\n#3 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(148): CListView->init()\n#4 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(173): CBaseController->createWidget(''zii.widgets.CLi...'', Array)\n#5 D:\\wamp\\www\\isms\\protected\\modules\\cms\\views\\node\\index.php(17): CBaseController->widget(''zii.widgets.CLi...'', Array)\n#6 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#7 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', Array, true)\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', Array, true)\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(783): CController->renderPartial(''index'', Array, true)\n#10 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(155): CController->render(''index'', Array, false)\n#11 D:\\wamp\\www\\isms\\protected\\extensions\\actions\\BrowseAction.php(43): WebBaseController->render(''index'', Array)\n#12 D:\\wamp\\www\\isms\\protected\\extensions\\actions\\BaseAction.php(60): BrowseAction->render()\n#13 D:\\wamp\\www\\yiiframework\\web\\actions\\CAction.php(75): BaseAction->run()\n#14 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CAction->runWithParams(Array)\n#15 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(BrowseAction))\n#16 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#17 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#18 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#19 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#20 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#21 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(BrowseAction), Array)\n#22 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#23 D:\\wamp\\www\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''/cms/node'')\n#24 D:\\wamp\\www\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''/cms/node'')\n#25 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#26 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#27 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#28 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#29 D:\\wamp\\www\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#30 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#31 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#32 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#33 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#34 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#35 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#36 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#37 D:\\wamp\\www\\isms\\index.php(42): CApplication->run()\n#38 {main}\nREQUEST_URI=/isms/\nHTTP_REFERER=http://localhost:8011/\n---'),
(3, 'error', 'exception.CHttpException.404', 1334888929, 'exception ''CHttpException'' with message ''Không tìm thấy yêu cầu view "Demo 404 page".'' in /var/www/html/yiiframework/web/actions/CViewAction.php:113\nStack trace:\n#0 /var/www/html/yiiframework/web/actions/CViewAction.php(124): CViewAction->resolveView(''Demo 404 page'')\n#1 /var/www/html/yiiframework/web/actions/CAction.php(75): CViewAction->run()\n#2 /var/www/html/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#3 /var/www/html/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(CViewAction))\n#4 /var/www/html/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#5 /var/www/html/isms/protected/components/WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#6 /var/www/html/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#7 /var/www/html/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#8 /var/www/html/yiiframework/web/CController.php(292): CFilterChain->run()\n#9 /var/www/html/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(CViewAction), Array)\n#10 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''page'')\n#11 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''site/page'')\n#12 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#13 /var/www/html/isms/index.php(21): CApplication->run()\n#14 {main}\nREQUEST_URI=/isms/index.php/site/page?view=Demo+404+page\nHTTP_REFERER=http://172.16.16.200/isms/index.php/site/page?view=interface\n---'),
(4, 'error', 'exception.CException', 1334888934, 'exception ''CException'' with message ''Alias "application.extensions.fullcalendar.FullcalendarGraphWidget" không có hiệu lực. Phải chắc chắn nó chỉ đến một tập tin PHP đã có.'' in /var/www/html/yiiframework/YiiBase.php:318\nStack trace:\n#0 /var/www/html/yiiframework/web/CWidgetFactory.php(147): YiiBase::import(''application.ext...'', true)\n#1 /var/www/html/yiiframework/web/CBaseController.php(147): CWidgetFactory->createWidget(Object(SiteController), ''application.ext...'', Array)\n#2 /var/www/html/yiiframework/web/CBaseController.php(173): CBaseController->createWidget(''application.ext...'', Array)\n#3 /var/www/html/isms/themes/shadow_dancer/views/site/pages/calendar.php(25): CBaseController->widget(''application.ext...'', Array)\n#4 /var/www/html/yiiframework/web/CBaseController.php(127): require(''/var/www/html/i...'')\n#5 /var/www/html/yiiframework/web/CBaseController.php(96): CBaseController->renderInternal(''/var/www/html/i...'', NULL, true)\n#6 /var/www/html/yiiframework/web/CController.php(870): CBaseController->renderFile(''/var/www/html/i...'', NULL, true)\n#7 /var/www/html/yiiframework/web/CController.php(783): CController->renderPartial(''pages/calendar'', NULL, true)\n#8 /var/www/html/isms/protected/components/WebBaseController.php(155): CController->render(''pages/calendar'', NULL, false)\n#9 /var/www/html/yiiframework/web/actions/CViewAction.php(141): WebBaseController->render(''pages/calendar'')\n#10 /var/www/html/yiiframework/web/actions/CAction.php(75): CViewAction->run()\n#11 /var/www/html/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#12 /var/www/html/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(CViewAction))\n#13 /var/www/html/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#14 /var/www/html/isms/protected/components/WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#15 /var/www/html/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#16 /var/www/html/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#17 /var/www/html/yiiframework/web/CController.php(292): CFilterChain->run()\n#18 /var/www/html/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(CViewAction), Array)\n#19 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''page'')\n#20 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''site/page'')\n#21 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#22 /var/www/html/isms/index.php(21): CApplication->run()\n#23 {main}\nREQUEST_URI=/isms/index.php/site/page?view=calendar\nHTTP_REFERER=http://172.16.16.200/isms/index.php/site/page?view=Demo+404+page\n---'),
(5, 'error', 'exception.CHttpException.404', 1334888939, 'exception ''CHttpException'' with message ''Không tìm thấy yêu cầu view "Demo 404 page".'' in /var/www/html/yiiframework/web/actions/CViewAction.php:113\nStack trace:\n#0 /var/www/html/yiiframework/web/actions/CViewAction.php(124): CViewAction->resolveView(''Demo 404 page'')\n#1 /var/www/html/yiiframework/web/actions/CAction.php(75): CViewAction->run()\n#2 /var/www/html/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#3 /var/www/html/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(CViewAction))\n#4 /var/www/html/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#5 /var/www/html/isms/protected/components/WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#6 /var/www/html/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#7 /var/www/html/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#8 /var/www/html/yiiframework/web/CController.php(292): CFilterChain->run()\n#9 /var/www/html/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(CViewAction), Array)\n#10 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''page'')\n#11 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''site/page'')\n#12 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#13 /var/www/html/isms/index.php(21): CApplication->run()\n#14 {main}\nREQUEST_URI=/isms/index.php/site/page?view=Demo+404+page\nHTTP_REFERER=http://172.16.16.200/isms/index.php/site/page?view=interface\n---'),
(6, 'info', 'application', 1334889231, 'Message  could not be added to messageSource table\nin /var/www/html/isms/protected/modules/translate/components/MPTranslate.php (76)\nin /var/www/html/isms/protected/modules/translate/TranslateModule.php (39)\nin /var/www/html/isms/themes/shadow_dancer/views/user/admin/index.php (41)\nin /var/www/html/isms/protected/components/WebBaseController.php (155)\nin /var/www/html/isms/protected/modules/user/controllers/AdminController.php (15)\nin /var/www/html/isms/protected/components/WebBaseController.php (104)\nin /var/www/html/isms/index.php (21)'),
(7, 'error', 'exception.CException', 1334889255, 'exception ''CException'' with message ''Alias "application.extensions.fullcalendar.FullcalendarGraphWidget" không có hiệu lực. Phải chắc chắn nó chỉ đến một tập tin PHP đã có.'' in /var/www/html/yiiframework/YiiBase.php:318\nStack trace:\n#0 /var/www/html/yiiframework/web/CWidgetFactory.php(147): YiiBase::import(''application.ext...'', true)\n#1 /var/www/html/yiiframework/web/CBaseController.php(147): CWidgetFactory->createWidget(Object(SiteController), ''application.ext...'', Array)\n#2 /var/www/html/yiiframework/web/CBaseController.php(173): CBaseController->createWidget(''application.ext...'', Array)\n#3 /var/www/html/isms/themes/shadow_dancer/views/site/pages/calendar.php(25): CBaseController->widget(''application.ext...'', Array)\n#4 /var/www/html/yiiframework/web/CBaseController.php(127): require(''/var/www/html/i...'')\n#5 /var/www/html/yiiframework/web/CBaseController.php(96): CBaseController->renderInternal(''/var/www/html/i...'', NULL, true)\n#6 /var/www/html/yiiframework/web/CController.php(870): CBaseController->renderFile(''/var/www/html/i...'', NULL, true)\n#7 /var/www/html/yiiframework/web/CController.php(783): CController->renderPartial(''pages/calendar'', NULL, true)\n#8 /var/www/html/isms/protected/components/WebBaseController.php(155): CController->render(''pages/calendar'', NULL, false)\n#9 /var/www/html/yiiframework/web/actions/CViewAction.php(141): WebBaseController->render(''pages/calendar'')\n#10 /var/www/html/yiiframework/web/actions/CAction.php(75): CViewAction->run()\n#11 /var/www/html/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#12 /var/www/html/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(CViewAction))\n#13 /var/www/html/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#14 /var/www/html/isms/protected/components/WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#15 /var/www/html/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#16 /var/www/html/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#17 /var/www/html/yiiframework/web/CController.php(292): CFilterChain->run()\n#18 /var/www/html/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(CViewAction), Array)\n#19 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''page'')\n#20 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''site/page'')\n#21 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#22 /var/www/html/isms/index.php(21): CApplication->run()\n#23 {main}\nREQUEST_URI=/isms/index.php/site/page?view=calendar\nHTTP_REFERER=http://172.16.16.200/isms/index.php/rights/assignment\n---'),
(8, 'error', 'exception.CHttpException.404', 1334889438, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in /var/www/html/yiiframework/web/CController.php:484\nStack trace:\n#0 /var/www/html/yiiframework/web/CController.php(271): CController->missingAction(''view'')\n#1 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''view'')\n#2 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#4 /var/www/html/isms/index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/3\nHTTP_REFERER=http://172.16.16.200/isms/index.php/isms/template\n---'),
(9, 'error', 'exception.CHttpException.404', 1334889444, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in /var/www/html/yiiframework/web/CController.php:484\nStack trace:\n#0 /var/www/html/yiiframework/web/CController.php(271): CController->missingAction(''view'')\n#1 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''view'')\n#2 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#4 /var/www/html/isms/index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/3\nHTTP_REFERER=http://172.16.16.200/isms/index.php/isms/template\n---'),
(10, 'error', 'exception.CException', 1334890578, 'exception ''CException'' with message ''CAssetManager.basePath "C:\\xampp\\htdocs\\isms\\assets" không hợp lệ. Hãy chắc rằng thư mục này có tồn tại và được phép ghi bởi Web server.'' in C:\\xampp\\htdocs\\yiiframework\\web\\CAssetManager.php:116\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CAssetManager.php(101): CAssetManager->setBasePath(''C:\\xampp\\htdocs...'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CAssetManager.php(219): CAssetManager->getBasePath()\n#2 C:\\xampp\\htdocs\\yiiframework\\zii\\widgets\\CListView.php(179): CAssetManager->publish(''C:\\xampp\\htdocs...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(148): CListView->init()\n#4 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(173): CBaseController->createWidget(''zii.widgets.CLi...'', Array)\n#5 C:\\xampp\\htdocs\\isms\\protected\\modules\\cms\\views\\node\\index.php(17): CBaseController->widget(''zii.widgets.CLi...'', Array)\n#6 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(127): require(''C:\\xampp\\htdocs...'')\n#7 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''C:\\xampp\\htdocs...'', Array, true)\n#8 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''C:\\xampp\\htdocs...'', Array, true)\n#9 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(783): CController->renderPartial(''index'', Array, true)\n#10 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(155): CController->render(''index'', Array, false)\n#11 C:\\xampp\\htdocs\\isms\\protected\\extensions\\actions\\BrowseAction.php(43): WebBaseController->render(''index'', Array)\n#12 C:\\xampp\\htdocs\\isms\\protected\\extensions\\actions\\BaseAction.php(60): BrowseAction->render()\n#13 C:\\xampp\\htdocs\\yiiframework\\web\\actions\\CAction.php(75): BaseAction->run()\n#14 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(309): CAction->runWithParams(Array)\n#15 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(BrowseAction))\n#16 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#17 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#18 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#19 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#20 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#21 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(BrowseAction), Array)\n#22 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#23 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''/cms/node'')\n#24 C:\\xampp\\htdocs\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''/cms/node'')\n#25 C:\\xampp\\htdocs\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#26 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#27 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#28 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#29 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#30 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#31 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#32 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#33 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#34 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#35 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#36 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#37 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#38 {main}\nREQUEST_URI=/isms/\n---'),
(11, 'error', 'exception.CHttpException.404', 1334892411, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in D:\\wamp\\www\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/3\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/template/index\n---'),
(12, 'error', 'exception.CHttpException.404', 1334892768, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/dailyreport".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/dailyrepor...'')\n#1 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/dailyreport\nHTTP_REFERER=http://localhost:8011/isms/index.php/isms/campaign/view/id/135\n---'),
(13, 'error', 'exception.CHttpException.404', 1334893265, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/3\nHTTP_REFERER=http://localhost/isms/index.php/isms/template\n---'),
(14, 'error', 'php', 1334905416, 'include(Controller.php) [<a href=''function.include''>function.include</a>]: failed to open stream: No such file or directory (D:\\wamp\\www\\yiiframework\\YiiBase.php:418)\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\controllers\\UssdController.php(4): spl_autoload_call()\n#1 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(344): require()\n#2 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(270): CWebApplication->createController()\n#3 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController()\n#4 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#5 D:\\wamp\\www\\isms\\index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/ussd\nin D:\\wamp\\www\\isms\\protected\\controllers\\UssdController.php (4)\nin D:\\wamp\\www\\isms\\index.php (21)'),
(15, 'error', 'exception.CException', 1334905437, 'exception ''CException'' with message ''Thuộc tính "UssdController.breadcrumbs" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:174\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\views\\ussd\\index.php(2): CComponent->__set(''breadcrumbs'', Array)\n#1 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', NULL, true)\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', NULL, true)\n#4 D:\\wamp\\www\\yiiframework\\web\\CController.php(783): CController->renderPartial(''index'', NULL, true)\n#5 D:\\wamp\\www\\isms\\protected\\controllers\\UssdController.php(12): CController->render(''index'')\n#6 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionIndex()\n#7 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(287): CController->runAction(Object(CInlineAction))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#10 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''ussd'')\n#12 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#13 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#14 {main}\nREQUEST_URI=/isms/index.php/ussd\nHTTP_REFERER=http://localhost:8011/isms/index.php/gii/controller\n---'),
(16, 'error', 'exception.CException', 1334906801, 'exception ''CException'' with message ''Thuộc tính "UssdController.settings_m" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\ussd\\index.php(5): CComponent->__get(''settings_m'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', NULL, true)\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', NULL, true)\n#4 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(40): CController->renderPartial(''index'', NULL)\n#5 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionIndex()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\CController.php(287): CController->runAction(Object(CInlineAction))\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#9 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#10 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd'')\n#11 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#12 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#13 {main}\nREQUEST_URI=/isms/index.php/isms/ussd\n---'),
(17, 'error', 'exception.CException', 1334906887, 'exception ''CException'' with message ''Thuộc tính "CWebApplication.settings" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\base\\CModule.php(106): CComponent->__get(''settings'')\n#1 D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\ussd\\index.php(5): CModule->__get(''settings'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#3 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', NULL, true)\n#4 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', NULL, true)\n#5 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(40): CController->renderPartial(''index'', NULL)\n#6 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionIndex()\n#7 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(287): CController->runAction(Object(CInlineAction))\n#9 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#10 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#11 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd'')\n#12 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#13 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#14 {main}\nREQUEST_URI=/isms/index.php/isms/ussd\n---'),
(18, 'error', 'exception.CHttpException.404', 1334907314, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "mode".'' in D:\\wamp\\www\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CController.php(271): CController->missingAction(''mode'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''mode'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd/mode/...'')\n#3 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/ussd/mode/whitelist\n---'),
(19, 'error', 'exception.CException', 1334907344, 'exception ''CException'' with message ''Thuộc tính "UssdController.isdn" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(67): CComponent->__get(''isdn'')\n#1 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionMylist()\n#2 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(287): CController->runAction(Object(CInlineAction))\n#4 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#5 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''mylist'')\n#6 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd/mylis...'')\n#7 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#8 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#9 {main}\nREQUEST_URI=/isms/index.php/isms/ussd/mylist/mode/whitelist\n---'),
(20, 'error', 'exception.CException', 1334907410, 'exception ''CException'' with message ''Thuộc tính "UssdController.isdn" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(68): CComponent->__get(''isdn'')\n#1 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionMylist()\n#2 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#4 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(24): CFilterChain->run()\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): UssdController->filterGetHeader(Object(CFilterChain))\n#6 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#9 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''mylist'')\n#10 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd/mylis...'')\n#11 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#12 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#13 {main}\nREQUEST_URI=/isms/index.php/isms/ussd/mylist/mode/whitelist\n---'),
(21, 'error', 'exception.CException', 1334907426, 'exception ''CException'' with message ''Thuộc tính "UssdController.settings_m" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\ussd\\list.php(26): CComponent->__get(''settings_m'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', NULL, true)\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', NULL, true)\n#4 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(71): CController->renderPartial(''list'')\n#5 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionMylist()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#8 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(24): CFilterChain->run()\n#9 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): UssdController->filterGetHeader(Object(CFilterChain))\n#10 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#11 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#12 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#13 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''mylist'')\n#14 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd/mylis...'')\n#15 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#16 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#17 {main}\nREQUEST_URI=/isms/index.php/isms/ussd/mylist/mode/whitelist\n---'),
(22, 'error', 'php', 1334907465, 'Declaration of AuthItemController::loadModel() should be compatible with that of WebBaseController::loadModel() (C:\\xampp\\htdocs\\isms\\protected\\modules\\rights\\controllers\\AuthItemController.php:10)\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(270): CWebApplication->createController()\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController()\n#2 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#3 C:\\xampp\\htdocs\\isms\\index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/rights/authItem/permissions\nin C:\\xampp\\htdocs\\isms\\protected\\modules\\rights\\controllers\\AuthItemController.php (10)\nin C:\\xampp\\htdocs\\isms\\index.php (21)'),
(23, 'error', 'exception.CException', 1334907526, 'exception ''CException'' with message ''Thuộc tính "UssdController.actionId" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\isms\\views\\ussd\\list.php(26): CComponent->__get(''actionId'')\n#1 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(127): require(''D:\\wamp\\www\\ism...'')\n#2 D:\\wamp\\www\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''D:\\wamp\\www\\ism...'', NULL, true)\n#3 D:\\wamp\\www\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''D:\\wamp\\www\\ism...'', NULL, true)\n#4 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(71): CController->renderPartial(''list'')\n#5 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionMylist()\n#6 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#7 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#8 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(24): CFilterChain->run()\n#9 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): UssdController->filterGetHeader(Object(CFilterChain))\n#10 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#11 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#12 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#13 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''mylist'')\n#14 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd/mylis...'')\n#15 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#16 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#17 {main}\nREQUEST_URI=/isms/index.php/isms/ussd/mylist/mode/whitelist\n---'),
(24, 'error', 'exception.CHttpException.404', 1334908297, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "ussd".'' in D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''ussd'')\n#1 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/ussd\nHTTP_REFERER=http://localhost:8011/isms/index.php/gii/controller\n---'),
(25, 'error', 'exception.CException', 1334908372, 'exception ''CException'' with message ''Thuộc tính "UssdController.first_id" chưa được định nghĩa.'' in D:\\wamp\\www\\yiiframework\\base\\CComponent.php:131\nStack trace:\n#0 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(121): CComponent->__get(''first_id'')\n#1 D:\\wamp\\www\\yiiframework\\web\\actions\\CInlineAction.php(50): UssdController->actionRegister()\n#2 D:\\wamp\\www\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#4 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(24): CFilterChain->run()\n#5 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): UssdController->filterGetHeader(Object(CFilterChain))\n#6 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#7 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#8 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#9 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): CController->run(''register'')\n#10 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/ussd/regis...'')\n#11 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#12 D:\\wamp\\www\\isms\\index.php(21): CApplication->run()\n#13 {main}\nREQUEST_URI=/isms/index.php/isms/ussd/register/1\n---'),
(26, 'error', 'php', 1334908408, 'Undefined index: id (D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php:121)\nStack trace:\n#0 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(134): UssdController->runAction()\n#1 D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php(24): CFilterChain->run()\n#2 D:\\wamp\\www\\yiiframework\\web\\filters\\CInlineFilter.php(59): UssdController->filterGetHeader()\n#3 D:\\wamp\\www\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter()\n#4 D:\\wamp\\www\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#5 D:\\wamp\\www\\yiiframework\\web\\CController.php(266): UssdController->runActionWithFilters()\n#6 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(276): UssdController->run()\n#7 D:\\wamp\\www\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController()\n#8 D:\\wamp\\www\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#9 D:\\wamp\\www\\isms\\index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/ussd/register/1\nin D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php (121)\nin D:\\wamp\\www\\isms\\protected\\modules\\isms\\controllers\\UssdController.php (24)\nin D:\\wamp\\www\\isms\\index.php (21)'),
(27, 'error', 'exception.CHttpException.404', 1334913951, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/report".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/report'')\n#1 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/report\nHTTP_REFERER=http://localhost/isms/index.php/isms/campaign\n---'),
(28, 'error', 'exception.CHttpException.404', 1334915473, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/report".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/report'')\n#1 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/report\nHTTP_REFERER=http://localhost/isms/index.php/isms/smsorder\n---'),
(29, 'error', 'php', 1334979696, 'include(Lookup.php) [<a href=''function.include''>function.include</a>]: failed to open stream: No such file or directory (C:\\xampp\\htdocs\\yiiframework\\YiiBase.php:418)\nStack trace:\n#0 C:\\xampp\\htdocs\\isms\\protected\\modules\\isms\\views\\campaign\\admin.php(56): spl_autoload_call()\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(127): require()\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(96): CampaignController->renderInternal()\n#3 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(870): CampaignController->renderFile()\n#4 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(783): CampaignController->renderPartial()\n#5 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(155): CampaignController->render()\n#6 C:\\xampp\\htdocs\\isms\\protected\\modules\\isms\\controllers\\CampaignController.php(155): CampaignController->render()\n#7 C:\\xampp\\htdocs\\yiiframework\\web\\actions\\CInlineAction.php(50): CampaignController->actionIndex()\n#8 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams()\n#9 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(134): CampaignController->runAction()\n#10 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#11 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(104): RightsFilter->filter()\n#12 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CInlineFilter.php(59): CampaignController->filterRights()\n#13 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter()\n#14 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#15 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(266): CampaignController->runActionWithFilters()\n#16 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CampaignController->run()\n#17 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController()\n#18 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#19 C:\\xampp\\htdocs\\isms\\index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/campaign\nin C:\\xampp\\htdocs\\isms\\protected\\modules\\isms\\views\\campaign\\admin.php (56)\nin C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php (155)\nin C:\\xampp\\htdocs\\isms\\protected\\modules\\isms\\controllers\\CampaignController.php (155)\nin C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php (104)\nin C:\\xampp\\htdocs\\isms\\index.php (21)'),
(30, 'error', 'exception.CHttpException.404', 1335169620, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/report".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/report'')\n#1 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/report\nHTTP_REFERER=http://localhost/isms/index.php/isms/ftpsetting\n---'),
(31, 'error', 'exception.CHttpException.404', 1335170727, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/3\nHTTP_REFERER=http://localhost/isms/index.php/isms/template\n---'),
(32, 'error', 'exception.CHttpException.404', 1335170731, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/4\nHTTP_REFERER=http://localhost/isms/index.php/isms/template\n---'),
(33, 'error', 'exception.CHttpException.404', 1335170735, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''view'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''view'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/template/v...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/template/view/id/5\nHTTP_REFERER=http://localhost/isms/index.php/isms/template\n---'),
(34, 'error', 'exception.CHttpException.404', 1335172829, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/report".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/report'')\n#1 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/report\nHTTP_REFERER=http://localhost/isms/index.php/isms/smsorder\n---');
INSERT INTO `YiiLog` (`id`, `level`, `category`, `logtime`, `message`) VALUES
(35, 'error', 'exception.CHttpException.404', 1335173008, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/report".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/report'')\n#1 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/report\nHTTP_REFERER=http://localhost/isms/index.php/isms/smsorder\n---'),
(36, 'error', 'exception.CHttpException.404', 1335173444, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "admin".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''admin'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''admin'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/organizati...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/organization/admin\nHTTP_REFERER=http://localhost/isms/index.php/isms/organization/create\n---'),
(37, 'error', 'exception.CHttpException.404', 1335174808, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "admin".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''admin'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''admin'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/filter/adm...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/filter/admin\nHTTP_REFERER=http://localhost/isms/index.php/isms/filter/create\n---'),
(38, 'error', 'exception.CHttpException.404', 1335174884, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "admin".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''admin'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''admin'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/filter/adm...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/filter/admin\nHTTP_REFERER=http://localhost/isms/index.php/isms/filter\n---'),
(39, 'error', 'exception.CHttpException.404', 1335175039, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "admin".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''admin'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''admin'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/filter/adm...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/filter/admin\nHTTP_REFERER=http://localhost/isms/index.php/isms/filter/create\n---'),
(40, 'error', 'exception.CHttpException.404', 1335236336, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/report".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php:280\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/report'')\n#1 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#2 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/report\nHTTP_REFERER=http://localhost/isms/index.php/isms/smsorder\n---'),
(41, 'error', 'exception.CHttpException.404', 1335237589, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "admin".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''admin'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''admin'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/smsorder/a...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/smsorder/admin\nHTTP_REFERER=http://localhost/isms/index.php/isms/smsorder/create\n---'),
(42, 'error', 'exception.CHttpException.404', 1335237860, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "admin".'' in C:\\xampp\\htdocs\\yiiframework\\web\\CController.php:484\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(271): CController->missingAction(''admin'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run(''admin'')\n#2 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController(''isms/filter/adm...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#4 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/filter/admin\nHTTP_REFERER=http://localhost/isms/index.php/isms/filter\n---'),
(43, 'error', 'exception.CException', 1335350413, 'exception ''CException'' with message ''CAssetManager.basePath "C:\\xampp\\htdocs\\isms\\assets" không hợp lệ. Hãy chắc rằng thư mục này có tồn tại và được phép ghi bởi Web server.'' in C:\\xampp\\htdocs\\yiiframework\\web\\CAssetManager.php:116\nStack trace:\n#0 C:\\xampp\\htdocs\\yiiframework\\web\\CAssetManager.php(101): CAssetManager->setBasePath(''C:\\xampp\\htdocs...'')\n#1 C:\\xampp\\htdocs\\yiiframework\\web\\CAssetManager.php(219): CAssetManager->getBasePath()\n#2 C:\\xampp\\htdocs\\yiiframework\\zii\\widgets\\CListView.php(179): CAssetManager->publish(''C:\\xampp\\htdocs...'')\n#3 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(148): CListView->init()\n#4 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(173): CBaseController->createWidget(''zii.widgets.CLi...'', Array)\n#5 C:\\xampp\\htdocs\\isms\\protected\\modules\\cms\\views\\node\\index.php(17): CBaseController->widget(''zii.widgets.CLi...'', Array)\n#6 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(127): require(''C:\\xampp\\htdocs...'')\n#7 C:\\xampp\\htdocs\\yiiframework\\web\\CBaseController.php(96): CBaseController->renderInternal(''C:\\xampp\\htdocs...'', Array, true)\n#8 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(870): CBaseController->renderFile(''C:\\xampp\\htdocs...'', Array, true)\n#9 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(783): CController->renderPartial(''index'', Array, true)\n#10 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(155): CController->render(''index'', Array, false)\n#11 C:\\xampp\\htdocs\\isms\\protected\\extensions\\actions\\BrowseAction.php(43): WebBaseController->render(''index'', Array)\n#12 C:\\xampp\\htdocs\\isms\\protected\\extensions\\actions\\BaseAction.php(60): BrowseAction->render()\n#13 C:\\xampp\\htdocs\\yiiframework\\web\\actions\\CAction.php(75): BaseAction->run()\n#14 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(309): CAction->runWithParams(Array)\n#15 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(BrowseAction))\n#16 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#17 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#18 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#19 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#20 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#21 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(BrowseAction), Array)\n#22 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#23 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(753): CWebApplication->runController(''/cms/node'')\n#24 C:\\xampp\\htdocs\\isms\\protected\\controllers\\SiteController.php(49): CController->forward(''/cms/node'')\n#25 C:\\xampp\\htdocs\\yiiframework\\web\\actions\\CInlineAction.php(50): SiteController->actionIndex()\n#26 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(309): CInlineAction->runWithParams(Array)\n#27 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#28 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilter.php(41): CFilterChain->run()\n#29 C:\\xampp\\htdocs\\isms\\protected\\components\\WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#30 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#31 C:\\xampp\\htdocs\\yiiframework\\web\\filters\\CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#32 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(292): CFilterChain->run()\n#33 C:\\xampp\\htdocs\\yiiframework\\web\\CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#34 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(276): CController->run('''')\n#35 C:\\xampp\\htdocs\\yiiframework\\web\\CWebApplication.php(135): CWebApplication->runController('''')\n#36 C:\\xampp\\htdocs\\yiiframework\\base\\CApplication.php(162): CWebApplication->processRequest()\n#37 C:\\xampp\\htdocs\\isms\\index.php(21): CApplication->run()\n#38 {main}\nREQUEST_URI=/isms/\n---'),
(44, 'error', 'exception.CHttpException.404', 1335421997, 'exception ''CHttpException'' with message ''Không thể giải quyết yêu cầu "isms/dailyreport".'' in /var/www/html/yiiframework/web/CWebApplication.php:280\nStack trace:\n#0 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/dailyrepor...'')\n#1 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#2 /var/www/html/isms/index.php(21): CApplication->run()\n#3 {main}\nREQUEST_URI=/isms/index.php/isms/dailyreport\nHTTP_REFERER=http://172.16.16.200/isms/index.php/isms/smsorder/create\n---'),
(45, 'error', 'php', 1335433532, 'array_merge() [<a href=''function.array-merge''>function.array-merge</a>]: Argument #2 is not an array (/var/www/isms/protected/modules/isms/views/template/_menu.php:19)\nStack trace:\n#0 /var/www/yiiframework/web/CBaseController.php(96): TemplateController->renderInternal()\n#1 /var/www/yiiframework/web/CController.php(870): TemplateController->renderFile()\n#2 /var/www/isms/protected/modules/isms/views/template/update.php(7): TemplateController->renderPartial()\n#3 /var/www/yiiframework/web/CBaseController.php(127): require()\n#4 /var/www/yiiframework/web/CBaseController.php(96): TemplateController->renderInternal()\n#5 /var/www/yiiframework/web/CController.php(870): TemplateController->renderFile()\n#6 /var/www/yiiframework/web/CController.php(783): TemplateController->renderPartial()\n#7 /var/www/isms/protected/components/WebBaseController.php(155): TemplateController->render()\n#8 /var/www/isms/protected/extensions/actions/BaseAction.php(80): TemplateController->render()\n#9 /var/www/isms/protected/extensions/actions/BaseAction.php(60): UpdateAction->render()\n#10 /var/www/yiiframework/web/actions/CAction.php(75): UpdateAction->run()\n#11 /var/www/yiiframework/web/CController.php(309): UpdateAction->runWithParams()\n#12 /var/www/yiiframework/web/filters/CFilterChain.php(134): TemplateController->runAction()\n#13 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#14 /var/www/isms/protected/components/WebBaseController.php(104): RightsFilter->filter()\n#15 /var/www/yiiframework/web/filters/CInlineFilter.php(59): TemplateController->filterRights()\n#16 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter()\n#17 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#18 /var/www/yiiframework/web/CController.php(266): TemplateController->runActionWithFilters()\n#19 /var/www/yiiframework/web/CWebApplication.php(276): TemplateController->run()\n#20 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController()\n#21 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#22 /var/www/isms/index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/template/update/id/3\nin /var/www/isms/protected/modules/isms/views/template/_menu.php (19)\nin /var/www/isms/protected/modules/isms/views/template/update.php (7)\nin /var/www/isms/protected/components/WebBaseController.php (155)\nin /var/www/isms/protected/extensions/actions/BaseAction.php (80)\nin /var/www/isms/protected/extensions/actions/BaseAction.php (60)\nin /var/www/isms/protected/components/WebBaseController.php (104)\nin /var/www/isms/index.php (21)'),
(46, 'error', 'php', 1335435487, 'Undefined variable: modelClass (/var/www/isms/protected/modules/isms/views/emailsetting/_menu.php:11)\nStack trace:\n#0 /var/www/yiiframework/web/CController.php(870): EmailsettingController->renderFile()\n#1 /var/www/isms/protected/modules/isms/views/emailsetting/admin.php(8): EmailsettingController->renderPartial()\n#2 /var/www/yiiframework/web/CBaseController.php(127): require()\n#3 /var/www/yiiframework/web/CBaseController.php(96): EmailsettingController->renderInternal()\n#4 /var/www/yiiframework/web/CController.php(870): EmailsettingController->renderFile()\n#5 /var/www/yiiframework/web/CController.php(783): EmailsettingController->renderPartial()\n#6 /var/www/isms/protected/components/WebBaseController.php(155): EmailsettingController->render()\n#7 /var/www/isms/protected/extensions/actions/AdminAction.php(45): EmailsettingController->render()\n#8 /var/www/isms/protected/extensions/actions/BaseAction.php(60): AdminAction->render()\n#9 /var/www/yiiframework/web/actions/CAction.php(75): AdminAction->run()\n#10 /var/www/yiiframework/web/CController.php(309): AdminAction->runWithParams()\n#11 /var/www/yiiframework/web/filters/CFilterChain.php(134): EmailsettingController->runAction()\n#12 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#13 /var/www/isms/protected/components/WebBaseController.php(104): RightsFilter->filter()\n#14 /var/www/yiiframework/web/filters/CInlineFilter.php(59): EmailsettingController->filterRights()\n#15 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter()\n#16 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#17 /var/www/yiiframework/web/CController.php(266): EmailsettingController->runActionWithFilters()\n#18 /var/www/yiiframework/web/CWebApplication.php(276): EmailsettingController->run()\n#19 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController()\n#20 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#21 /var/www/isms/index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/emailsetting\nin /var/www/isms/protected/modules/isms/views/emailsetting/_menu.php (11)\nin /var/www/isms/protected/modules/isms/views/emailsetting/admin.php (8)\nin /var/www/isms/protected/components/WebBaseController.php (155)\nin /var/www/isms/protected/extensions/actions/AdminAction.php (45)\nin /var/www/isms/protected/extensions/actions/BaseAction.php (60)\nin /var/www/isms/protected/components/WebBaseController.php (104)\nin /var/www/isms/index.php (21)'),
(47, 'error', 'exception.CHttpException.404', 1335436466, 'exception ''CHttpException'' with message ''The requested page does not exist.'' in /var/www/isms/protected/extensions/actions/UpdateAction.php:53\nStack trace:\n#0 /var/www/isms/protected/extensions/actions/BaseAction.php(50): UpdateAction->model()\n#1 /var/www/yiiframework/web/actions/CAction.php(75): BaseAction->run()\n#2 /var/www/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#3 /var/www/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(UpdateAction))\n#4 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#5 /var/www/isms/protected/components/WebBaseController.php(104): CFilter->filter(Object(CFilterChain))\n#6 /var/www/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#7 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#8 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#9 /var/www/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(UpdateAction), Array)\n#10 /var/www/yiiframework/web/CWebApplication.php(276): CController->run(''update'')\n#11 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/emailsetti...'')\n#12 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#13 /var/www/isms/index.php(21): CApplication->run()\n#14 {main}\nREQUEST_URI=/isms/index.php/isms/emailsetting/update/id/index\nHTTP_REFERER=http://localhost/isms/index.php/isms/emailsetting/update/id/1\n---'),
(48, 'error', 'php', 1335437777, 'Undefined variable: modelClass (/var/www/isms/protected/modules/isms/views/campaign/_menu.php:11)\nStack trace:\n#0 /var/www/yiiframework/web/CController.php(870): CampaignController->renderFile()\n#1 /var/www/isms/protected/modules/isms/views/campaign/admin.php(6): CampaignController->renderPartial()\n#2 /var/www/yiiframework/web/CBaseController.php(127): require()\n#3 /var/www/yiiframework/web/CBaseController.php(96): CampaignController->renderInternal()\n#4 /var/www/yiiframework/web/CController.php(870): CampaignController->renderFile()\n#5 /var/www/yiiframework/web/CController.php(783): CampaignController->renderPartial()\n#6 /var/www/isms/protected/components/WebBaseController.php(155): CampaignController->render()\n#7 /var/www/isms/protected/modules/isms/controllers/CampaignController.php(155): CampaignController->render()\n#8 /var/www/yiiframework/web/actions/CInlineAction.php(50): CampaignController->actionIndex()\n#9 /var/www/yiiframework/web/CController.php(309): CInlineAction->runWithParams()\n#10 /var/www/yiiframework/web/filters/CFilterChain.php(134): CampaignController->runAction()\n#11 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#12 /var/www/isms/protected/components/WebBaseController.php(104): RightsFilter->filter()\n#13 /var/www/yiiframework/web/filters/CInlineFilter.php(59): CampaignController->filterRights()\n#14 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter()\n#15 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#16 /var/www/yiiframework/web/CController.php(266): CampaignController->runActionWithFilters()\n#17 /var/www/yiiframework/web/CWebApplication.php(276): CampaignController->run()\n#18 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController()\n#19 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#20 /var/www/isms/index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/campaign\nin /var/www/isms/protected/modules/isms/views/campaign/_menu.php (11)\nin /var/www/isms/protected/modules/isms/views/campaign/admin.php (6)\nin /var/www/isms/protected/components/WebBaseController.php (155)\nin /var/www/isms/protected/modules/isms/controllers/CampaignController.php (155)\nin /var/www/isms/protected/components/WebBaseController.php (104)\nin /var/www/isms/index.php (21)'),
(49, 'error', 'exception.CHttpException.404', 1335928486, 'exception ''CHttpException'' with message ''Hệ thống không thể tìm được hành động yêu cầu "view".'' in /var/www/yiiframework/web/CController.php:484\nStack trace:\n#0 /var/www/yiiframework/web/CController.php(271): CController->missingAction(''view'')\n#1 /var/www/yiiframework/web/CWebApplication.php(276): CController->run(''view'')\n#2 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/dailyrepor...'')\n#3 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#4 /var/www/isms/index.php(21): CApplication->run()\n#5 {main}\nREQUEST_URI=/isms/index.php/isms/dailyreport/view/id/1\nHTTP_REFERER=http://localhost/isms/index.php/isms/dailyreport/create\n---'),
(50, 'error', 'exception.CException', 1335928756, 'exception ''CException'' with message ''SmsorderController không tìm được view: "_menu".'' in /var/www/yiiframework/web/CController.php:879\nStack trace:\n#0 /var/www/isms/protected/modules/isms/views/smsorder/view.php(7): CController->renderPartial(''_menu'', Array)\n#1 /var/www/yiiframework/web/CBaseController.php(127): require(''/var/www/isms/p...'')\n#2 /var/www/yiiframework/web/CBaseController.php(96): CBaseController->renderInternal(''/var/www/isms/p...'', Array, true)\n#3 /var/www/yiiframework/web/CController.php(870): CBaseController->renderFile(''/var/www/isms/p...'', Array, true)\n#4 /var/www/yiiframework/web/CController.php(783): CController->renderPartial(''view'', Array, true)\n#5 /var/www/isms/protected/components/WebBaseController.php(162): CController->render(''view'', Array, false)\n#6 /var/www/isms/protected/extensions/actions/ViewAction.php(30): WebBaseController->render(''view'', Array)\n#7 /var/www/isms/protected/extensions/actions/BaseAction.php(60): ViewAction->render()\n#8 /var/www/yiiframework/web/actions/CAction.php(75): BaseAction->run()\n#9 /var/www/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#10 /var/www/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(ViewAction))\n#11 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#12 /var/www/isms/protected/components/WebBaseController.php(99): CFilter->filter(Object(CFilterChain))\n#13 /var/www/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterSetReturnUrl(Object(CFilterChain))\n#14 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#15 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#16 /var/www/isms/protected/components/WebBaseController.php(111): CFilter->filter(Object(CFilterChain))\n#17 /var/www/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#18 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#19 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#20 /var/www/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(ViewAction), Array)\n#21 /var/www/yiiframework/web/CWebApplication.php(276): CController->run(''view'')\n#22 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/smsorder/v...'')\n#23 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#24 /var/www/isms/index.php(21): CApplication->run()\n#25 {main}\nREQUEST_URI=/isms/index.php/isms/smsorder/view/id/3\nHTTP_REFERER=http://localhost/isms/index.php/isms/smsorder/create\n---'),
(51, 'error', 'php', 1335928796, 'array_merge(): Argument #2 is not an array (/var/www/isms/protected/modules/isms/views/smsorder/_menu.php:19)\nStack trace:\n#0 /var/www/yiiframework/web/CBaseController.php(96): SmsorderController->renderInternal()\n#1 /var/www/yiiframework/web/CController.php(870): SmsorderController->renderFile()\n#2 /var/www/isms/protected/modules/isms/views/smsorder/view.php(7): SmsorderController->renderPartial()\n#3 /var/www/yiiframework/web/CBaseController.php(127): require()\n#4 /var/www/yiiframework/web/CBaseController.php(96): SmsorderController->renderInternal()\n#5 /var/www/yiiframework/web/CController.php(870): SmsorderController->renderFile()\n#6 /var/www/yiiframework/web/CController.php(783): SmsorderController->renderPartial()\n#7 /var/www/isms/protected/components/WebBaseController.php(162): SmsorderController->render()\n#8 /var/www/isms/protected/extensions/actions/ViewAction.php(30): SmsorderController->render()\n#9 /var/www/isms/protected/extensions/actions/BaseAction.php(60): ViewAction->render()\n#10 /var/www/yiiframework/web/actions/CAction.php(75): ViewAction->run()\n#11 /var/www/yiiframework/web/CController.php(309): ViewAction->runWithParams()\n#12 /var/www/yiiframework/web/filters/CFilterChain.php(134): SmsorderController->runAction()\n#13 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#14 /var/www/isms/protected/components/WebBaseController.php(99): ESetReturnUrlFilter->filter()\n#15 /var/www/yiiframework/web/filters/CInlineFilter.php(59): SmsorderController->filterSetReturnUrl()\n#16 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter()\n#17 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#18 /var/www/isms/protected/components/WebBaseController.php(111): RightsFilter->filter()\n#19 /var/www/yiiframework/web/filters/CInlineFilter.php(59): SmsorderController->filterRights()\n#20 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter()\n#21 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#22 /var/www/yiiframework/web/CController.php(266): SmsorderController->runActionWithFilters()\n#23 /var/www/yiiframework/web/CWebApplication.php(276): SmsorderController->run()\n#24 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController()\n#25 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#26 /var/www/isms/index.php(21): CWebApplication->run()\nREQUEST_URI=/isms/index.php/isms/smsorder/view/id/3\nin /var/www/isms/protected/modules/isms/views/smsorder/_menu.php (19)\nin /var/www/isms/protected/modules/isms/views/smsorder/view.php (7)\nin /var/www/isms/protected/components/WebBaseController.php (162)\nin /var/www/isms/protected/extensions/actions/ViewAction.php (30)\nin /var/www/isms/protected/extensions/actions/BaseAction.php (60)\nin /var/www/isms/protected/components/WebBaseController.php (99)\nin /var/www/isms/protected/components/WebBaseController.php (111)\nin /var/www/isms/index.php (21)'),
(52, 'error', 'exception.CHttpException.404', 1335950232, 'exception ''CHttpException'' with message ''The requested page does not exist.'' in /var/www/isms/protected/extensions/actions/UpdateAction.php:53\nStack trace:\n#0 /var/www/isms/protected/extensions/actions/ViewAction.php(26): UpdateAction->model()\n#1 /var/www/isms/protected/extensions/actions/BaseAction.php(50): ViewAction->model()\n#2 /var/www/yiiframework/web/actions/CAction.php(75): BaseAction->run()\n#3 /var/www/yiiframework/web/CController.php(309): CAction->runWithParams(Array)\n#4 /var/www/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(ViewAction))\n#5 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#6 /var/www/isms/protected/components/WebBaseController.php(99): CFilter->filter(Object(CFilterChain))\n#7 /var/www/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterSetReturnUrl(Object(CFilterChain))\n#8 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#9 /var/www/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#10 /var/www/isms/protected/components/WebBaseController.php(111): CFilter->filter(Object(CFilterChain))\n#11 /var/www/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#12 /var/www/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#13 /var/www/yiiframework/web/CController.php(292): CFilterChain->run()\n#14 /var/www/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(ViewAction), Array)\n#15 /var/www/yiiframework/web/CWebApplication.php(276): CController->run(''view'')\n#16 /var/www/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/datafile/v...'')\n#17 /var/www/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#18 /var/www/isms/index.php(21): CApplication->run()\n#19 {main}\nREQUEST_URI=/isms/index.php/isms/datafile/view/id/index\nHTTP_REFERER=http://localhost/isms/index.php/isms/datafile/view/id/3\n---'),
(53, 'error', 'exception.CException', 1336030726, 'exception ''CException'' with message ''Alias "ext.widgets.multiselect.EMultiSelect" không có hiệu lực. Phải chắc chắn nó chỉ đến một tập tin PHP đã có.'' in /var/www/html/yiiframework/YiiBase.php:318\nStack trace:\n#0 /var/www/html/yiiframework/web/CWidgetFactory.php(147): YiiBase::import(''ext.widgets.mul...'', true)\n#1 /var/www/html/yiiframework/web/CBaseController.php(147): CWidgetFactory->createWidget(Object(CampaignController), ''ext.widgets.mul...'', Array)\n#2 /var/www/html/yiiframework/web/CBaseController.php(173): CBaseController->createWidget(''ext.widgets.mul...'', Array)\n#3 /var/www/html/isms/protected/modules/isms/views/campaign/_form.php(17): CBaseController->widget(''ext.widgets.mul...'', Array)\n#4 /var/www/html/yiiframework/web/CBaseController.php(127): require(''/var/www/html/i...'')\n#5 /var/www/html/yiiframework/web/CBaseController.php(96): CBaseController->renderInternal(''/var/www/html/i...'', Array, true)\n#6 /var/www/html/yiiframework/web/CController.php(870): CBaseController->renderFile(''/var/www/html/i...'', Array, true)\n#7 /var/www/html/isms/protected/modules/isms/views/campaign/update.php(18): CController->renderPartial(''_form'', Array)\n#8 /var/www/html/yiiframework/web/CBaseController.php(127): require(''/var/www/html/i...'')\n#9 /var/www/html/yiiframework/web/CBaseController.php(96): CBaseController->renderInternal(''/var/www/html/i...'', Array, true)\n#10 /var/www/html/yiiframework/web/CController.php(870): CBaseController->renderFile(''/var/www/html/i...'', Array, true)\n#11 /var/www/html/yiiframework/web/CController.php(783): CController->renderPartial(''update'', Array, true)\n#12 /var/www/html/isms/protected/components/WebBaseController.php(162): CController->render(''update'', Array, false)\n#13 /var/www/html/isms/protected/modules/isms/controllers/CampaignController.php(94): WebBaseController->render(''update'', Array)\n#14 /var/www/html/yiiframework/web/actions/CInlineAction.php(50): CampaignController->actionUpdate()\n#15 /var/www/html/yiiframework/web/CController.php(309): CInlineAction->runWithParams(Array)\n#16 /var/www/html/yiiframework/web/filters/CFilterChain.php(134): CController->runAction(Object(CInlineAction))\n#17 /var/www/html/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#18 /var/www/html/isms/protected/components/WebBaseController.php(99): CFilter->filter(Object(CFilterChain))\n#19 /var/www/html/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterSetReturnUrl(Object(CFilterChain))\n#20 /var/www/html/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#21 /var/www/html/yiiframework/web/filters/CFilter.php(41): CFilterChain->run()\n#22 /var/www/html/isms/protected/components/WebBaseController.php(111): CFilter->filter(Object(CFilterChain))\n#23 /var/www/html/yiiframework/web/filters/CInlineFilter.php(59): WebBaseController->filterRights(Object(CFilterChain))\n#24 /var/www/html/yiiframework/web/filters/CFilterChain.php(131): CInlineFilter->filter(Object(CFilterChain))\n#25 /var/www/html/yiiframework/web/CController.php(292): CFilterChain->run()\n#26 /var/www/html/yiiframework/web/CController.php(266): CController->runActionWithFilters(Object(CInlineAction), Array)\n#27 /var/www/html/yiiframework/web/CWebApplication.php(276): CController->run(''update'')\n#28 /var/www/html/yiiframework/web/CWebApplication.php(135): CWebApplication->runController(''isms/campaign/u...'')\n#29 /var/www/html/yiiframework/base/CApplication.php(162): CWebApplication->processRequest()\n#30 /var/www/html/isms/index.php(21): CApplication->run()\n#31 {main}\nREQUEST_URI=/isms/index.php/isms/campaign/update/id/1\nHTTP_REFERER=http://172.16.16.200/isms/index.php/isms/campaign\n---'),
(54, 'info', 'application', 1336031682, 'Message  could not be added to messageSource table\nin /var/www/html/isms/protected/modules/translate/components/MPTranslate.php (76)\nin /var/www/html/isms/protected/modules/translate/TranslateModule.php (39)\nin /var/www/html/isms/themes/shadow_dancer/views/user/admin/index.php (41)\nin /var/www/html/isms/protected/components/WebBaseController.php (162)\nin /var/www/html/isms/protected/modules/user/controllers/AdminController.php (15)\nin /var/www/html/isms/protected/components/WebBaseController.php (99)\nin /var/www/html/isms/protected/components/WebBaseController.php (111)\nin /var/www/html/isms/index.php (21)'),
(55, 'info', 'application', 1336031702, 'Message  could not be added to messageSource table\nin /var/www/html/isms/protected/modules/translate/components/MPTranslate.php (76)\nin /var/www/html/isms/protected/modules/translate/TranslateModule.php (39)\nin /var/www/html/isms/themes/shadow_dancer/views/user/admin/index.php (41)\nin /var/www/html/isms/protected/components/WebBaseController.php (162)\nin /var/www/html/isms/protected/modules/user/controllers/AdminController.php (15)\nin /var/www/html/isms/protected/components/WebBaseController.php (99)\nin /var/www/html/isms/protected/components/WebBaseController.php (111)\nin /var/www/html/isms/index.php (21)'),
(56, 'info', 'application', 1336031717, 'Message  could not be added to messageSource table\nin /var/www/html/isms/protected/modules/translate/components/MPTranslate.php (76)\nin /var/www/html/isms/protected/modules/translate/TranslateModule.php (39)\nin /var/www/html/isms/themes/shadow_dancer/views/user/admin/index.php (41)\nin /var/www/html/isms/protected/components/WebBaseController.php (162)\nin /var/www/html/isms/protected/modules/user/controllers/AdminController.php (15)\nin /var/www/html/isms/protected/components/WebBaseController.php (99)\nin /var/www/html/isms/protected/components/WebBaseController.php (111)\nin /var/www/html/isms/index.php (21)'),
(57, 'info', 'application', 1336031727, 'Message  could not be added to messageSource table\nin /var/www/html/isms/protected/modules/translate/components/MPTranslate.php (76)\nin /var/www/html/isms/protected/modules/translate/TranslateModule.php (39)\nin /var/www/html/isms/themes/shadow_dancer/views/user/admin/index.php (41)\nin /var/www/html/isms/protected/components/WebBaseController.php (162)\nin /var/www/html/isms/protected/modules/user/controllers/AdminController.php (15)\nin /var/www/html/isms/protected/components/WebBaseController.php (99)\nin /var/www/html/isms/protected/components/WebBaseController.php (111)\nin /var/www/html/isms/index.php (21)'),
(58, 'info', 'application', 1336031764, 'Message  could not be added to messageSource table\nin /var/www/html/isms/protected/modules/translate/components/MPTranslate.php (76)\nin /var/www/html/isms/protected/modules/translate/TranslateModule.php (39)\nin /var/www/html/isms/themes/shadow_dancer/views/user/admin/index.php (41)\nin /var/www/html/isms/protected/components/WebBaseController.php (162)\nin /var/www/html/isms/protected/modules/user/controllers/AdminController.php (15)\nin /var/www/html/isms/protected/components/WebBaseController.php (99)\nin /var/www/html/isms/protected/components/WebBaseController.php (111)\nin /var/www/html/isms/index.php (21)');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `filter`
--
ALTER TABLE `filter`
  ADD CONSTRAINT `filter_ibfk_1` FOREIGN KEY (`ftpblack`) REFERENCES `ftpsetting` (`id`),
  ADD CONSTRAINT `filter_ibfk_2` FOREIGN KEY (`ftpwhite`) REFERENCES `ftpsetting` (`id`);
